package com.agrisense.controller;

import com.agrisense.entity.Farm;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/farms")
@CrossOrigin(origins = "*")
public class FarmController {

    // Spring Data JPA FarmRepository handles database interactions
    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> getAllFarms() {
        return ResponseEntity.ok(Collections.emptyList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getFarmById(@PathVariable String id) {
        return ResponseEntity.ok(Map.of("id", id, "status", "ACTIVE"));
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> createFarm(@RequestBody Farm farm) {
        return ResponseEntity.ok(Map.of("message", "Farm registered successfully", "id", farm.getId()));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateFarm(@PathVariable String id, @RequestBody Farm farm) {
        return ResponseEntity.ok(Map.of("message", "Farm updated", "id", id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteFarm(@PathVariable String id) {
        return ResponseEntity.ok(Map.of("message", "Farm deleted successfully"));
    }
}
