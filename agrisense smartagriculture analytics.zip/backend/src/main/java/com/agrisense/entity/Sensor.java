package com.agrisense.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sensors")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Sensor {

    @Id
    @Column(name = "id", length = 36)
    private String id;

    @Column(name = "farm_id", nullable = false)
    private String farmId;

    @Column(name = "type", nullable = false)
    private String type;

    @Column(name = "current_value", nullable = false)
    private Double currentValue;

    @Column(name = "unit", nullable = false)
    private String unit;

    @Column(name = "status", nullable = false)
    private String status;

    @Column(name = "battery_level")
    private Integer batteryLevel;

    @Column(name = "depth_or_height")
    private String depthOrHeight;

    @Column(name = "min_normal")
    private Double minNormal;

    @Column(name = "max_normal")
    private Double maxNormal;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;
}
