package com.agrisense.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sensor_readings", indexes = {
    @Index(name = "idx_sensor_time", columnList = "sensor_id, timestamp")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SensorReading {

    @Id
    @Column(name = "id", length = 36)
    private String id;

    @Column(name = "sensor_id", nullable = false)
    private String sensorId;

    @Column(name = "farm_id", nullable = false)
    private String farmId;

    @Column(name = "sensor_type", nullable = false)
    private String sensorType;

    @Column(name = "value", nullable = false)
    private Double value;

    @Column(name = "unit", nullable = false)
    private String unit;

    @Column(name = "timestamp", nullable = false)
    private LocalDateTime timestamp;
}
