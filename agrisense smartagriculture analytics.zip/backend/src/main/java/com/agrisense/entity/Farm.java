package com.agrisense.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "farms")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Farm {

    @Id
    @Column(name = "id", length = 36)
    private String id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "owner_id", nullable = false)
    private String ownerId;

    @Column(name = "location", nullable = false)
    private String location;

    @Column(name = "area", nullable = false)
    private Double area;

    @Column(name = "crop", nullable = false)
    private String crop;

    @Column(name = "soil_type", nullable = false)
    private String soilType;

    @Column(name = "sensor_count")
    private Integer sensorCount;

    @Column(name = "status", nullable = false)
    private String status;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
