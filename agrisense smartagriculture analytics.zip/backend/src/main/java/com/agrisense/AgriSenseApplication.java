package com.agrisense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class AgriSenseApplication {

    public static void main(String[] args) {
        SpringApplication.run(AgriSenseApplication.class, args);
        System.out.println("🌾 AgriSense Spring Boot 3 Backend initialized on port 8080");
    }
}
