import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { DashboardPage } from './pages/DashboardPage';
import { FarmsPage } from './pages/FarmsPage';
import { WeatherAnalyticsPage } from './pages/WeatherAnalyticsPage';
import { SoilAnalyticsPage } from './pages/SoilAnalyticsPage';
import { SensorMonitoringPage } from './pages/SensorMonitoringPage';
import { CropAnalyticsPage } from './pages/CropAnalyticsPage';
import { IrrigationRecommendationPage } from './pages/IrrigationRecommendationPage';
import { DiseaseRiskPage } from './pages/DiseaseRiskPage';
import { MLPredictionsPage } from './pages/MLPredictionsPage';
import { ResearchAnalyticsPage } from './pages/ResearchAnalyticsPage';
import { AlertsPage } from './pages/AlertsPage';
import { ReportsPage } from './pages/ReportsPage';
import { DatasetManagementPage } from './pages/DatasetManagementPage';
import { UserManagementPage } from './pages/UserManagementPage';
import { SettingsPage } from './pages/SettingsPage';
import { Menu } from 'lucide-react';

function AppContent() {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState<string>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);

  // Standalone public pages
  if (currentPage === 'landing') {
    return <LandingPage onNavigate={(p) => setCurrentPage(p)} />;
  }

  if (currentPage === 'login') {
    return <LoginPage onNavigate={(p) => setCurrentPage(p)} />;
  }

  if (currentPage === 'register') {
    return <RegisterPage onNavigate={(p) => setCurrentPage(p)} />;
  }

  // Dashboard router
  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage onNavigate={(p) => setCurrentPage(p)} />;
      case 'farms':
        return <FarmsPage onNavigate={(p) => setCurrentPage(p)} />;
      case 'weather':
        return <WeatherAnalyticsPage />;
      case 'soil':
        return <SoilAnalyticsPage />;
      case 'sensors':
        return <SensorMonitoringPage />;
      case 'crops':
        return <CropAnalyticsPage />;
      case 'irrigation':
        return <IrrigationRecommendationPage />;
      case 'disease-risk':
        return <DiseaseRiskPage />;
      case 'ml-predictions':
        return <MLPredictionsPage />;
      case 'correlative-analytics':
      case 'research-analytics':
        return <ResearchAnalyticsPage />;
      case 'alerts':
        return <AlertsPage />;
      case 'reports':
        return <ReportsPage />;
      case 'datasets':
        return <DatasetManagementPage />;
      case 'users':
        return <UserManagementPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage onNavigate={(p) => setCurrentPage(p)} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50 text-slate-800">
      {/* Sidebar navigation */}
      <Sidebar
        currentPage={currentPage}
        onNavigate={(p) => setCurrentPage(p)}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main Container */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Navbar */}
        <div className="flex items-center">
          <button
            onClick={() => setIsSidebarOpen(true)}
            className="p-3 text-slate-600 hover:text-slate-900 lg:hidden bg-white border-b border-r border-slate-200"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1 min-w-0">
            <Navbar
              currentPage={currentPage}
              onNavigate={(p) => setCurrentPage(p)}
              onOpenAlerts={() => setCurrentPage('alerts')}
            />
          </div>
        </div>

        {/* Content Body */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {renderPage()}
          </div>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
