import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Plus,
  Eye,
  Edit2,
  Trash2,
  Wheat,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Radio,
  Activity,
  CloudSun,
  Droplets,
  Layers,
} from 'lucide-react';
import { farmService, sensorService, weatherService, soilService } from '../services/api';
import { Farm, Sensor, WeatherData, SoilData } from '../types';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { useAuth } from '../context/AuthContext';

export const FarmsPage: React.FC<{ onNavigate: (page: string) => void }> = ({ onNavigate }) => {
  const { setSelectedFarmId } = useAuth();
  const [farms, setFarms] = useState<Farm[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterCrop, setFilterCrop] = useState('ALL');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [activeFarm, setActiveFarm] = useState<Farm | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    area: '',
    crop: 'Rice',
    soilType: 'Loam' as Farm['soilType'],
    status: 'ACTIVE' as Farm['status'],
  });

  // Details state
  const [farmSensors, setFarmSensors] = useState<Sensor[]>([]);
  const [farmWeather, setFarmWeather] = useState<WeatherData | null>(null);
  const [farmSoil, setFarmSoil] = useState<SoilData | null>(null);

  const loadFarms = async () => {
    try {
      setIsLoading(true);
      const res = await farmService.getAll();
      setFarms(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadFarms();
  }, []);

  const handleCreateFarm = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await farmService.create({
        name: formData.name,
        location: formData.location,
        area: Number(formData.area),
        crop: formData.crop,
        soilType: formData.soilType,
      });
      setShowAddModal(false);
      setFormData({ name: '', location: '', area: '', crop: 'Rice', soilType: 'Loam', status: 'ACTIVE' });
      loadFarms();
    } catch (err) {
      alert('Failed to register new farm.');
    }
  };

  const handleUpdateFarm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeFarm) return;
    try {
      await farmService.update(activeFarm.id, {
        name: formData.name,
        location: formData.location,
        area: Number(formData.area),
        crop: formData.crop,
        soilType: formData.soilType,
        status: formData.status,
      });
      setShowEditModal(false);
      loadFarms();
    } catch (err) {
      alert('Failed to update farm details.');
    }
  };

  const handleDeleteFarm = async (id: string, name: string) => {
    if (confirm(`Are you sure you want to remove farm "${name}"? All associated sensors will be detached.`)) {
      try {
        await farmService.delete(id);
        loadFarms();
      } catch (err) {
        alert('Failed to delete farm.');
      }
    }
  };

  const handleViewDetails = async (farm: Farm) => {
    setActiveFarm(farm);
    setShowDetailsModal(true);
    try {
      const [sns, wth, sl] = await Promise.all([
        sensorService.getAll({ farmId: farm.id }),
        weatherService.getWeather(farm.id),
        soilService.getSoilData(farm.id),
      ]);
      setFarmSensors(sns);
      setFarmWeather(wth);
      setFarmSoil(sl);
    } catch (err) {
      console.error(err);
    }
  };

  const handleOpenEdit = (farm: Farm) => {
    setActiveFarm(farm);
    setFormData({
      name: farm.name,
      location: farm.location,
      area: farm.area.toString(),
      crop: farm.crop,
      soilType: farm.soilType,
      status: farm.status,
    });
    setShowEditModal(true);
  };

  const filteredFarms = farms.filter((f) => {
    const matchesSearch =
      f.name.toLowerCase().includes(search.toLowerCase()) ||
      f.location.toLowerCase().includes(search.toLowerCase()) ||
      f.crop.toLowerCase().includes(search.toLowerCase());
    const matchesCrop = filterCrop === 'ALL' || f.crop.toLowerCase().includes(filterCrop.toLowerCase());
    return matchesSearch && matchesCrop;
  });

  return (
    <div className="space-y-6">
      {/* Header with Search and Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-800 tracking-tight">Farm Management</h2>
          <p className="text-xs text-slate-500">
            Registered agricultural plots, soil classification, sensor deployments & active crops
          </p>
        </div>

        <button
          onClick={() => {
            setFormData({ name: '', location: '', area: '', crop: 'Rice', soilType: 'Loam', status: 'ACTIVE' });
            setShowAddModal(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" /> Add New Farm
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search farm name, location, crop..."
            className="w-full pl-9 pr-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs text-slate-500 font-medium">Filter Crop:</span>
          <select
            value={filterCrop}
            onChange={(e) => setFilterCrop(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-800 font-semibold focus:outline-hidden cursor-pointer"
          >
            <option value="ALL">All Crops</option>
            <option value="Rice">Rice</option>
            <option value="Wheat">Wheat</option>
            <option value="Cotton">Cotton</option>
            <option value="Maize">Maize</option>
          </select>
        </div>
      </div>

      {/* Farm Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {isLoading ? (
          <LoadingSpinner message="Loading farm registers..." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
                <tr>
                  <th className="px-4 py-3.5">Farm ID</th>
                  <th className="px-4 py-3.5">Farm Name</th>
                  <th className="px-4 py-3.5">Location</th>
                  <th className="px-4 py-3.5">Area (Acres)</th>
                  <th className="px-4 py-3.5">Primary Crop</th>
                  <th className="px-4 py-3.5">Soil Type</th>
                  <th className="px-4 py-3.5">Sensors</th>
                  <th className="px-4 py-3.5">Status</th>
                  <th className="px-4 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredFarms.map((farm) => (
                  <tr key={farm.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 font-mono text-slate-400 font-semibold">{farm.id}</td>
                    <td className="px-4 py-3 font-bold text-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-500" />
                        {farm.name}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-600">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {farm.location}
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono font-medium text-slate-700">{farm.area} ac</td>
                    <td className="px-4 py-3">
                      <span className="font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                        {farm.crop}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{farm.soilType}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 font-mono font-semibold text-slate-700">
                        <Radio className="w-3.5 h-3.5 text-sky-500" />
                        {farm.sensorCount} probes
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={farm.status === 'ACTIVE' ? 'green' : 'gray'} size="sm" dot>
                        {farm.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleViewDetails(farm)}
                          title="View Details"
                          className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(farm)}
                          title="Edit Farm"
                          className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteFarm(farm.id, farm.name)}
                          title="Delete Farm"
                          className="p-1.5 text-slate-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ADD FARM MODAL */}
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Register New Agricultural Field"
        subtitle="Add a new farm for telemetry monitoring and automated analytics."
      >
        <form onSubmit={handleCreateFarm} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Farm Name</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. Kaveri Organic Basin"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Location / State</label>
              <input
                type="text"
                required
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="e.g. Tamil Nadu, India"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Area (Acres)</label>
              <input
                type="number"
                step="0.1"
                required
                value={formData.area}
                onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                placeholder="25.0"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Primary Crop</label>
              <select
                value={formData.crop}
                onChange={(e) => setFormData({ ...formData, crop: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
              >
                <option value="Rice (Paddy)">Rice (Paddy)</option>
                <option value="Wheat">Wheat</option>
                <option value="Cotton">Cotton</option>
                <option value="Maize">Maize</option>
                <option value="Tomato">Tomato</option>
                <option value="Chilli">Chilli</option>
                <option value="Groundnut">Groundnut</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Soil Classification</label>
              <select
                value={formData.soilType}
                onChange={(e) => setFormData({ ...formData, soilType: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
              >
                <option value="Loam">Loam</option>
                <option value="Clay">Clay</option>
                <option value="Sandy Loam">Sandy Loam</option>
                <option value="Black Soil">Black Soil</option>
                <option value="Alluvial">Alluvial</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setShowAddModal(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl"
            >
              Deploy & Provision Sensors
            </button>
          </div>
        </form>
      </Modal>

      {/* EDIT FARM MODAL */}
      <Modal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        title="Edit Farm Parameters"
        subtitle={`Updating settings for ${activeFarm?.name}`}
      >
        <form onSubmit={handleUpdateFarm} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Farm Name</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Location</label>
              <input
                type="text"
                required
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Area (Acres)</label>
              <input
                type="number"
                step="0.1"
                required
                value={formData.area}
                onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Crop</label>
              <input
                type="text"
                required
                value={formData.crop}
                onChange={(e) => setFormData({ ...formData, crop: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Status</label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
              >
                <option value="ACTIVE">ACTIVE</option>
                <option value="INACTIVE">INACTIVE</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setShowEditModal(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl"
            >
              Save Changes
            </button>
          </div>
        </form>
      </Modal>

      {/* FARM DETAILS MODAL */}
      <Modal
        isOpen={showDetailsModal}
        onClose={() => setShowDetailsModal(false)}
        title={activeFarm?.name || 'Farm Details'}
        subtitle={`Coordinates: ${activeFarm?.latitude.toFixed(4)}°N, ${activeFarm?.longitude.toFixed(4)}°E`}
        maxWidth="2xl"
      >
        <div className="space-y-5 text-xs">
          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold">Area</span>
              <p className="text-base font-bold text-slate-800 mt-0.5">{activeFarm?.area} Acres</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold">Primary Crop</span>
              <p className="text-base font-bold text-emerald-700 mt-0.5">{activeFarm?.crop}</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold">Soil Type</span>
              <p className="text-base font-bold text-slate-800 mt-0.5">{activeFarm?.soilType}</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold">Deployed Sensors</span>
              <p className="text-base font-bold text-sky-700 mt-0.5">{farmSensors.length} Probes</p>
            </div>
          </div>

          {/* Current Microclimate Weather */}
          <div className="p-4 bg-sky-50/60 rounded-xl border border-sky-200">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <CloudSun className="w-4 h-4 text-sky-600" />
                <h4 className="font-bold text-sky-950">Field Microclimate Weather</h4>
              </div>
              <span className="text-[10px] text-sky-700 font-medium">Condition: {farmWeather?.condition}</span>
            </div>
            <div className="grid grid-cols-4 gap-2 text-center">
              <div>
                <span className="text-slate-500 text-[10px]">Temperature</span>
                <p className="font-bold text-slate-800 text-sm">{farmWeather?.temperature} °C</p>
              </div>
              <div>
                <span className="text-slate-500 text-[10px]">Humidity</span>
                <p className="font-bold text-slate-800 text-sm">{farmWeather?.humidity} %</p>
              </div>
              <div>
                <span className="text-slate-500 text-[10px]">Wind Speed</span>
                <p className="font-bold text-slate-800 text-sm">{farmWeather?.windSpeed} km/h</p>
              </div>
              <div>
                <span className="text-slate-500 text-[10px]">Rainfall</span>
                <p className="font-bold text-slate-800 text-sm">{farmWeather?.rainfall} mm</p>
              </div>
            </div>
          </div>

          {/* Attached Sensors List */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-bold text-slate-800">Deployed In-Situ Sensors ({farmSensors.length})</h4>
              <button
                onClick={() => {
                  if (activeFarm) setSelectedFarmId(activeFarm.id);
                  setShowDetailsModal(false);
                  onNavigate('sensors');
                }}
                className="text-emerald-600 font-bold hover:underline"
              >
                Go to Sensor Hub →
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
              {farmSensors.map((s) => (
                <div key={s.id} className="p-2.5 bg-white border border-slate-200 rounded-xl flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-slate-800">{s.type}</p>
                    <p className="text-[10px] text-slate-400 font-mono">{s.depthOrHeight || 'Ground probe'}</p>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-sm text-emerald-700">
                      {s.currentValue} {s.unit}
                    </span>
                    <Badge variant={s.status === 'ONLINE' ? 'green' : 'amber'} size="sm" dot>
                      {s.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action button to select as active farm */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-slate-500">Established: {activeFarm?.establishedDate}</span>
            <button
              onClick={() => {
                if (activeFarm) setSelectedFarmId(activeFarm.id);
                setShowDetailsModal(false);
                onNavigate('dashboard');
              }}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs"
            >
              Set as Active Dashboard Farm
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
