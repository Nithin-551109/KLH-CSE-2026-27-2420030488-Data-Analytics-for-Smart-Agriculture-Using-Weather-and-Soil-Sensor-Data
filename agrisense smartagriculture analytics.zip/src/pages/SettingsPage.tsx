import React, { useState, useEffect } from 'react';
import {
  Sliders,
  Save,
  CheckCircle2,
  Bell,
  Activity,
  Droplets,
  Thermometer,
  ShieldCheck,
  User as UserIcon,
  Sparkles,
} from 'lucide-react';
import { settingsService } from '../services/api';
import { ThresholdSettings } from '../types';
import { useAuth } from '../context/AuthContext';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const SettingsPage: React.FC = () => {
  const { user, triggerLivePulse } = useAuth();
  const [settings, setSettings] = useState<ThresholdSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    settingsService.get().then((data) => {
      setSettings(data);
      setIsLoading(false);
    });
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setIsSaving(true);
    setSaveSuccess(false);
    try {
      await settingsService.update(settings);
      setSaveSuccess(true);
      triggerLivePulse();
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      alert('Failed to save settings to server.');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading || !settings) {
    return <LoadingSpinner message="Loading agronomic threshold configuration..." />;
  }

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
            System Preferences
          </span>
          <span className="text-xs text-slate-400 font-mono">Dynamic Agronomic Threshold Configuration</span>
        </div>
        <h2 className="text-xl font-black text-slate-800 tracking-tight">System & Sensor Threshold Settings</h2>
        <p className="text-xs text-slate-500">
          Configure physical sensor alerting boundaries, profile settings, and automated irrigation thresholds
        </p>
      </div>

      {saveSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900 font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          Agronomic threshold configurations persisted to backend database successfully.
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Sensor Thresholds Card */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600">
                <Sliders className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800">Agronomic Sensor Thresholds</h3>
                <p className="text-xs text-slate-400">Controls automated condition flags (DRY, OPTIMAL, WET, CRITICAL)</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5 text-xs">
            {/* Soil Moisture Min / Max */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <label className="block font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-emerald-600" /> Minimum Soil Moisture (%)
              </label>
              <input
                type="number"
                step="0.5"
                value={settings.minSoilMoisture}
                onChange={(e) => setSettings({ ...settings, minSoilMoisture: parseFloat(e.target.value) || 0 })}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Trigger for DRY & Irrigation Alert</span>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <label className="block font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-sky-600" /> Maximum Soil Moisture (%)
              </label>
              <input
                type="number"
                step="0.5"
                value={settings.maxSoilMoisture}
                onChange={(e) => setSettings({ ...settings, maxSoilMoisture: parseFloat(e.target.value) || 0 })}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Trigger for WET & Waterlogging Alert</span>
            </div>

            {/* pH Min / Max */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <label className="block font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-purple-600" /> Optimal pH Range
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="0.1"
                  value={settings.minPh}
                  onChange={(e) => setSettings({ ...settings, minPh: parseFloat(e.target.value) || 0 })}
                  className="w-1/2 px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold"
                />
                <span className="text-slate-400">to</span>
                <input
                  type="number"
                  step="0.1"
                  value={settings.maxPh}
                  onChange={(e) => setSettings({ ...settings, maxPh: parseFloat(e.target.value) || 0 })}
                  className="w-1/2 px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">Acidity / Alkalinity warning limit</span>
            </div>

            {/* Temp Warning */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <label className="block font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                <Thermometer className="w-3.5 h-3.5 text-amber-600" /> Temperature Warning (°C)
              </label>
              <input
                type="number"
                step="0.5"
                value={settings.tempWarning}
                onChange={(e) => setSettings({ ...settings, tempWarning: parseFloat(e.target.value) || 0 })}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Heat stress alert trigger</span>
            </div>

            {/* Humidity Warning */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <label className="block font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-sky-600" /> Humidity Warning (%)
              </label>
              <input
                type="number"
                value={settings.humidityWarning}
                onChange={(e) => setSettings({ ...settings, humidityWarning: parseFloat(e.target.value) || 0 })}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Fungal pathogen incubation trigger</span>
            </div>

            {/* Rainfall Threshold */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <label className="block font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-blue-600" /> Heavy Rainfall Limit (mm)
              </label>
              <input
                type="number"
                value={settings.rainfallThreshold}
                onChange={(e) => setSettings({ ...settings, rainfallThreshold: parseFloat(e.target.value) || 0 })}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Excess precipitation drainage alert</span>
            </div>
          </div>
        </div>

        {/* System Automation & Alerts Toggle */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-xl bg-sky-50 text-sky-600">
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800">Automated Alert Dispatcher</h3>
                <p className="text-xs text-slate-400">Background sensor polling and rule execution</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
            <div>
              <p className="font-bold text-slate-800">Automated Threshold Alerts</p>
              <p className="text-slate-500">Automatically broadcast field alerts when sensor values cross limits.</p>
            </div>
            <input
              type="checkbox"
              checked={settings.autoAlertsEnabled}
              onChange={(e) => setSettings({ ...settings, autoAlertsEnabled: e.target.checked })}
              className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Profile Card */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-xl bg-purple-50 text-purple-600">
                <UserIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800">Account Profile</h3>
                <p className="text-xs text-slate-400">Authenticated user details</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">User Name</label>
              <p className="font-bold text-slate-800 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                {user?.name}
              </p>
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Email</label>
              <p className="font-bold text-slate-800 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                {user?.email}
              </p>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
          >
            <Save className="w-4 h-4" />
            {isSaving ? 'Persisting Changes...' : 'Save Configuration'}
          </button>
        </div>
      </form>
    </div>
  );
};
