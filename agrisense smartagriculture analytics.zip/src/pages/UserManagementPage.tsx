import React, { useState, useEffect } from 'react';
import {
  Users,
  UserPlus,
  ShieldCheck,
  Wheat,
  UserCheck,
  Edit2,
  Trash2,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { userService, farmService } from '../services/api';
import { User, Farm, UserRole } from '../types';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const UserManagementPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [farms, setFarms] = useState<Farm[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');

  // Add user modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'FARMER' as UserRole,
    farmId: '',
  });

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [uList, fList] = await Promise.all([userService.getAll(), farmService.getAll()]);
      setUsers(uList);
      setFarms(fList);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await userService.create(formData);
      setShowAddModal(false);
      setFormData({ name: '', email: '', password: '', role: 'FARMER', farmId: '' });
      loadData();
    } catch (err) {
      alert('Failed to register user.');
    }
  };

  const handleToggleStatus = async (user: User) => {
    const newStatus = user.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    try {
      await userService.update(user.id, { status: newStatus });
      loadData();
    } catch (err) {
      alert('Failed to update user status.');
    }
  };

  const handleDeleteUser = async (id: string, name: string) => {
    if (confirm(`Remove access for user "${name}"?`)) {
      try {
        await userService.delete(id);
        loadData();
      } catch (err) {
        alert('Failed to delete user.');
      }
    }
  };

  const filteredUsers = users.filter((u) => {
    const matchesSearch = u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase());
    const matchesRole = roleFilter === 'ALL' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-800 tracking-tight">User & Role Management</h2>
          <p className="text-xs text-slate-500">
            Role-Based Access Control (RBAC): Admin, Farmer, and Researcher system privileges
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors shrink-0"
        >
          <UserPlus className="w-4 h-4" /> Add System User
        </button>
      </div>

      {/* Role Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-purple-50/60 border border-purple-200 rounded-2xl flex items-center gap-3.5">
          <div className="p-3 bg-purple-600 text-white rounded-xl">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700">Administrators</span>
            <p className="text-xl font-black text-purple-950 font-mono">
              {users.filter((u) => u.role === 'ADMIN').length}
            </p>
            <p className="text-[10px] text-purple-700">Full system & farm controls</p>
          </div>
        </div>

        <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-2xl flex items-center gap-3.5">
          <div className="p-3 bg-emerald-600 text-white rounded-xl">
            <Wheat className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">Farmers</span>
            <p className="text-xl font-black text-emerald-950 font-mono">
              {users.filter((u) => u.role === 'FARMER').length}
            </p>
            <p className="text-[10px] text-emerald-700">Field telemetry & irrigation advisories</p>
          </div>
        </div>

        <div className="p-4 bg-sky-50/60 border border-sky-200 rounded-2xl flex items-center gap-3.5">
          <div className="p-3 bg-sky-600 text-white rounded-xl">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-sky-700">Researchers</span>
            <p className="text-xl font-black text-sky-950 font-mono">
              {users.filter((u) => u.role === 'RESEARCHER').length}
            </p>
            <p className="text-[10px] text-sky-700">Dataset preprocessing & ML models</p>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search user name or email..."
            className="w-full pl-9 pr-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs text-slate-500 font-medium">Filter Role:</span>
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800 cursor-pointer"
          >
            <option value="ALL">All Roles</option>
            <option value="ADMIN">ADMIN</option>
            <option value="FARMER">FARMER</option>
            <option value="RESEARCHER">RESEARCHER</option>
          </select>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {isLoading ? (
          <LoadingSpinner message="Querying user directory..." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
                <tr>
                  <th className="px-4 py-3.5">User</th>
                  <th className="px-4 py-3.5">Email Address</th>
                  <th className="px-4 py-3.5">Role</th>
                  <th className="px-4 py-3.5">Assigned Farm</th>
                  <th className="px-4 py-3.5">Status</th>
                  <th className="px-4 py-3.5">Created Date</th>
                  <th className="px-4 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredUsers.map((u) => {
                  const assignedFarm = farms.find((f) => f.id === u.farmId);
                  return (
                    <tr key={u.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3 font-bold text-slate-800">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white font-bold flex items-center justify-center text-xs">
                            {u.name.charAt(0)}
                          </div>
                          <span>{u.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-slate-600 font-mono">{u.email}</td>
                      <td className="px-4 py-3">
                        <Badge
                          variant={u.role === 'ADMIN' ? 'purple' : u.role === 'RESEARCHER' ? 'blue' : 'green'}
                          size="sm"
                        >
                          {u.role}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-slate-600">
                        {assignedFarm ? assignedFarm.name : 'Global Access'}
                      </td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => handleToggleStatus(u)}
                          className="cursor-pointer"
                          title="Click to toggle status"
                        >
                          <Badge variant={u.status === 'ACTIVE' ? 'green' : 'gray'} size="sm" dot>
                            {u.status}
                          </Badge>
                        </button>
                      </td>
                      <td className="px-4 py-3 text-slate-400 font-mono">
                        {u.createdAt ? u.createdAt.slice(0, 10) : '2026-01-15'}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => handleDeleteUser(u.id, u.name)}
                            title="Delete User"
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ADD USER MODAL */}
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Add System User"
        subtitle="Create an account with role-based dashboard permissions."
      >
        <form onSubmit={handleCreateUser} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Full Name</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. Priya Sundaram"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Email Address</label>
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="priya@agrisense.org"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Temporary Password</label>
            <input
              type="password"
              required
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              placeholder="••••••••"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Role</label>
              <select
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold"
              >
                <option value="FARMER">FARMER</option>
                <option value="RESEARCHER">RESEARCHER</option>
                <option value="ADMIN">ADMIN</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Assign to Farm</label>
              <select
                value={formData.farmId}
                onChange={(e) => setFormData({ ...formData, farmId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
              >
                <option value="">None (Global)</option>
                {farms.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setShowAddModal(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl"
            >
              Provision Account
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
