import React, { useState, useEffect } from 'react';
import {
  Droplets,
  Calendar,
  CloudSun,
  Activity,
  Layers,
  Thermometer,
  CloudRain,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  Send,
  Info,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { mlService, recommendationService, farmService, soilService } from '../services/api';
import { Recommendation, Farm, SoilData } from '../types';
import { Badge } from '../components/common/Badge';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const IrrigationRecommendationPage: React.FC = () => {
  const { selectedFarmId, liveTick } = useAuth();
  const [activeRec, setActiveRec] = useState<Recommendation | null>(null);
  const [soil, setSoil] = useState<SoilData | null>(null);
  const [farm, setFarm] = useState<Farm | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Interactive Simulator Form
  const [simForm, setSimForm] = useState({
    soilMoisture: 26.5,
    temperature: 32.0,
    humidity: 58,
    rainfallForecast: 0.0,
    cropType: 'Rice',
    growthStage: 'Tillering',
    soilType: 'Loam',
  });

  const [simResult, setSimResult] = useState<any | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [recs, s, f] = await Promise.all([
        recommendationService.getAll(selectedFarmId),
        soilService.getSoilData(selectedFarmId),
        farmService.getById(selectedFarmId),
      ]);
      const irrigationRec = recs.find((r) => r.type === 'IRRIGATION') || recs[0];
      setActiveRec(irrigationRec);
      setSoil(s);
      setFarm(f);

      // Pre-fill simulator
      if (s) {
        setSimForm((prev) => ({
          ...prev,
          soilMoisture: s.moisture,
          temperature: s.temperature,
          cropType: f?.crop || 'Rice',
          soilType: f?.soilType || 'Loam',
        }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedFarmId, liveTick]);

  const handleRunSimulator = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSimulating(true);
    try {
      const res = await mlService.predictIrrigation(simForm);
      setSimResult(res);
    } catch (err) {
      alert('Failed to execute irrigation model.');
    } finally {
      setIsSimulating(false);
    }
  };

  if (isLoading && !activeRec) {
    return <LoadingSpinner message="Calculating Penman-Monteith water balances and ML irrigation triggers..." />;
  }

  const priorityStyles = {
    HIGH: { border: 'border-rose-300', bg: 'bg-rose-50/50', badge: 'red' as const },
    MEDIUM: { border: 'border-amber-300', bg: 'bg-amber-50/50', badge: 'amber' as const },
    LOW: { border: 'border-emerald-300', bg: 'bg-emerald-50/50', badge: 'green' as const },
  };

  const recPriority = activeRec?.priority || 'MEDIUM';
  const pStyle = priorityStyles[recPriority];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-bold uppercase tracking-wider text-sky-700 bg-sky-50 px-2 py-0.5 rounded-full border border-sky-200">
            Intelligent Agro-Hydrology Engine
          </span>
          <span className="text-xs text-slate-400 font-mono">Gradient Boosted Tree Decision Model</span>
        </div>
        <h2 className="text-xl font-black text-slate-800 tracking-tight">Precision Irrigation Advisory</h2>
        <p className="text-xs text-slate-500">
          Synthesizes root zone moisture, evapotranspiration rates, crop growth stage, and 48-hour precipitation forecasts
        </p>
      </div>

      {/* PRIMARY RECOMMENDATION CARD */}
      <div className={`p-6 rounded-3xl bg-white border-2 ${pStyle.border} shadow-md space-y-6`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div className="flex items-start gap-4">
            <div className="p-3.5 rounded-2xl bg-sky-600 text-white shadow-md shadow-sky-600/30">
              <Droplets className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500">
                  Model Recommendation
                </span>
                <Badge variant={activeRec?.irrigationRequired === 'YES' ? 'amber' : 'green'} size="sm" dot>
                  IRRIGATION REQUIRED: {activeRec?.irrigationRequired}
                </Badge>
                <Badge variant={pStyle.badge} size="sm">
                  Priority: {activeRec?.priority}
                </Badge>
              </div>
              <h3 className="text-xl font-black text-slate-900">{activeRec?.title}</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Field: <strong>{farm?.name}</strong> • Soil Type: <strong>{farm?.soilType}</strong> • Confidence: {(Number(activeRec?.confidenceScore || 0.94) * 100).toFixed(0)}%
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-sky-50/80 border border-sky-200/80 rounded-2xl p-4 shrink-0">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-sky-700">Recommended Water Depth</span>
              <p className="text-2xl font-black text-sky-950 font-mono mt-0.5">
                {activeRec?.recommendedWaterAmount}
              </p>
            </div>
          </div>
        </div>

        {/* Reason and Scheduling Details */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Meteorological & Soil Rationale</h4>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs text-slate-700 leading-relaxed font-medium">
              {activeRec?.reason}
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200/80 text-xs text-emerald-900 leading-relaxed font-semibold">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-emerald-700 mb-1">Recommended Execution</span>
              {activeRec?.recommendedAction}
            </div>
          </div>

          {/* Key Hydrological Factors */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Feature Inputs Evaluated</h4>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 font-medium">Root Moisture Deficit</span>
                <p className="text-base font-bold text-slate-800 font-mono mt-0.5">
                  {soil?.moisture}% (Threshold: 30%)
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 font-medium">48-Hour Precipitation</span>
                <p className="text-base font-bold text-sky-700 font-mono mt-0.5">
                  0.0 mm (0% chance)
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 font-medium">Evapotranspiration ET₀</span>
                <p className="text-base font-bold text-slate-800 font-mono mt-0.5">
                  5.4 mm/day
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 font-medium">Crop Growth Stage</span>
                <p className="text-base font-bold text-emerald-700 font-mono mt-0.5">
                  Tillering (High water need)
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Mandatory Research / Regulatory Disclaimer */}
        <div className="pt-4 border-t border-slate-100 flex items-start gap-2.5 text-xs text-slate-500 bg-amber-50/40 p-3.5 rounded-xl border border-amber-200/60">
          <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <p>
            <strong>Research & Analytics Output Notice:</strong> These water volumes and scheduling windows are model predictions computed from calibrated soil moisture capacitance sensors and microclimate forecasts. Soil compaction and localized hardpans should be verified before continuous drip fertigation.
          </p>
        </div>
      </div>

      {/* INTERACTIVE IRRIGATION SIMULATOR WORKBENCH */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-800">What-If Irrigation Simulator</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Test model response to changing weather scenarios</span>
        </div>

        <form onSubmit={handleRunSimulator} className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Soil Moisture ({simForm.soilMoisture}%)
              </label>
              <input
                type="range"
                min="10"
                max="80"
                step="0.5"
                value={simForm.soilMoisture}
                onChange={(e) => setSimForm({ ...simForm, soilMoisture: parseFloat(e.target.value) })}
                className="w-full accent-emerald-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>10% (Bone dry)</span>
                <span>80% (Saturated)</span>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Temperature ({simForm.temperature}°C)
              </label>
              <input
                type="range"
                min="15"
                max="45"
                step="0.5"
                value={simForm.temperature}
                onChange={(e) => setSimForm({ ...simForm, temperature: parseFloat(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>15°C (Cool)</span>
                <span>45°C (Extreme)</span>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Forecasted Rain ({simForm.rainfallForecast} mm)
              </label>
              <input
                type="range"
                min="0"
                max="50"
                step="1"
                value={simForm.rainfallForecast}
                onChange={(e) => setSimForm({ ...simForm, rainfallForecast: parseFloat(e.target.value) })}
                className="w-full accent-sky-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>0 mm</span>
                <span>50 mm (Downpour)</span>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Crop Variety</label>
              <select
                value={simForm.cropType}
                onChange={(e) => setSimForm({ ...simForm, cropType: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800"
              >
                <option value="Rice">Rice (Paddy)</option>
                <option value="Wheat">Wheat</option>
                <option value="Cotton">Cotton</option>
                <option value="Maize">Maize</option>
                <option value="Tomato">Tomato</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <span className="text-xs text-slate-500 font-medium">
              Invokes backend <code>/api/ml/predict/irrigation</code> endpoint
            </span>
            <button
              type="submit"
              disabled={isSimulating}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              {isSimulating ? 'Evaluating Decision Trees...' : 'Compute Model Prediction'}
            </button>
          </div>
        </form>

        {/* Simulator Prediction Output */}
        {simResult && (
          <div className="mt-6 p-5 rounded-2xl bg-slate-900 text-white animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" /> Live Machine Learning Inference
              </span>
              <span className="text-xs font-mono text-slate-400">Confidence: {(simResult.confidence * 100).toFixed(0)}%</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
              <div className="p-3 bg-slate-800/80 rounded-xl">
                <span className="text-[10px] text-slate-400 font-semibold">Irrigation Required</span>
                <p className="text-xl font-black text-emerald-400 mt-0.5">{simResult.prediction}</p>
              </div>
              <div className="p-3 bg-slate-800/80 rounded-xl">
                <span className="text-[10px] text-slate-400 font-semibold">Calculated Priority</span>
                <p className="text-xl font-black text-amber-400 mt-0.5">{simResult.priority}</p>
              </div>
              <div className="p-3 bg-slate-800/80 rounded-xl">
                <span className="text-[10px] text-slate-400 font-semibold">Recommended Depth</span>
                <p className="text-xl font-black text-sky-400 mt-0.5">{simResult.recommendedWaterAmount}</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-mono">
              Rationale: {simResult.reason}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
