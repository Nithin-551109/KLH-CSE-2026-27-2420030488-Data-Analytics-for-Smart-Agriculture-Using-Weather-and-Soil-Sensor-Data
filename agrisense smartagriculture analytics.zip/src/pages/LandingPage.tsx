import React from 'react';
import {
  Wheat,
  CloudSun,
  Activity,
  Cpu,
  BrainCircuit,
  Droplets,
  Database,
  ArrowRight,
  TrendingUp,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface LandingPageProps {
  onNavigate: (page: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();

  const workflowSteps = [
    { title: 'Weather Data', desc: 'Real-time microclimate precipitation, temperature & radiation', icon: CloudSun, color: 'text-sky-600 bg-sky-50 border-sky-200' },
    { title: 'Soil Sensors', desc: 'In-situ capacitance probes: Moisture, pH, NPK & EC', icon: Activity, color: 'text-emerald-600 bg-emerald-50 border-emerald-200' },
    { title: 'Data Collection', desc: 'IoT telemetry gateway aggregating sensor feeds', icon: Cpu, color: 'text-amber-600 bg-amber-50 border-amber-200' },
    { title: 'Data Preprocessing', desc: 'Outlier detection, 3-sigma clipping & Kalman smoothing', icon: Database, color: 'text-indigo-600 bg-indigo-50 border-indigo-200' },
    { title: 'Data Analytics', desc: 'Descriptive stats, Pearson correlation & trend analysis', icon: TrendingUp, color: 'text-teal-600 bg-teal-50 border-teal-200' },
    { title: 'Machine Learning', desc: 'Random Forest, Gradient Boosting & KNN models', icon: BrainCircuit, color: 'text-purple-600 bg-purple-50 border-purple-200' },
    { title: 'Agricultural Insights', desc: 'Moisture deficits, stress flags & nutrient balances', icon: Sparkles, color: 'text-emerald-600 bg-emerald-50 border-emerald-200' },
    { title: 'Decision Support', desc: 'Optimal irrigation scheduling & field mitigation', icon: Droplets, color: 'text-blue-600 bg-blue-50 border-blue-200' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      {/* Top Banner Navigation */}
      <nav className="border-b border-slate-200 bg-white/95 backdrop-blur-md sticky top-0 z-50 px-6 lg:px-12 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('dashboard')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white shadow-md shadow-emerald-900/20">
            <Wheat className="w-6 h-6" />
          </div>
          <div>
            <span className="text-lg font-black tracking-tight text-slate-900">AgriSense</span>
            <span className="text-xs ml-2 font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">Research Platform</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {user ? (
            <button
              onClick={() => onNavigate('dashboard')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
            >
              Open Dashboard <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('login')}
                className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Sign In
              </button>
              <button
                onClick={() => onNavigate('register')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-xs transition-colors"
              >
                Register
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 px-6 lg:px-12 max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold mb-6">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            Empowering Modern Agriculture Through Data Analytics
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Smart Agriculture Through <span className="text-emerald-600">Data-Driven Insights</span>
          </h1>

          <p className="mt-6 text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl mx-auto">
            Analyze weather and soil sensor data to make smarter decisions for irrigation, crop health and farm management.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => onNavigate('dashboard')}
              className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold rounded-xl shadow-md hover:shadow-lg shadow-emerald-700/20 transition-all"
            >
              View Live Dashboard <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('ml-predictions')}
              className="inline-flex items-center gap-2 px-5 py-3 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-sm font-semibold rounded-xl shadow-2xs transition-colors"
            >
              <BrainCircuit className="w-4 h-4 text-emerald-600" />
              Explore ML Models
            </button>
            <button
              onClick={() => onNavigate('irrigation')}
              className="inline-flex items-center gap-2 px-5 py-3 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-sm font-semibold rounded-xl shadow-2xs transition-colors"
            >
              <Droplets className="w-4 h-4 text-sky-600" />
              Irrigation Advisory
            </button>
          </div>

          {/* Academic Project Badge */}
          <div className="mt-8 pt-6 border-t border-slate-200/80 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-500">
            <span>Project: <strong className="text-slate-700">IoT & Sensor Analytics for Precision Farming</strong></span>
            <span>Target: <strong className="text-slate-700">Water Conservation & Yield Optimization</strong></span>
            <span>Engine: <strong className="text-slate-700">PostgreSQL + Spring Boot + Python ML + React</strong></span>
          </div>
        </div>
      </section>

      {/* Architecture & Workflow Diagram */}
      <section className="bg-white py-16 border-y border-slate-200 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">End-to-End Architectural Workflow</h2>
            <p className="mt-2 text-sm text-slate-500">
              From raw telemetry acquisition to actionable machine learning agronomic prescriptions.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {workflowSteps.map((step, idx) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.title}
                  className="relative p-5 rounded-2xl border border-slate-200/80 bg-slate-50/50 hover:bg-white hover:shadow-md transition-all group"
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[11px] font-black text-slate-400 group-hover:text-emerald-600 transition-colors">
                      STEP 0{idx + 1}
                    </span>
                    <div className={`p-2 rounded-lg border ${step.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                  </div>
                  <h3 className="text-sm font-bold text-slate-800 mb-1">{step.title}</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">{step.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Data Sources & Sensors */}
      <section className="py-16 px-6 lg:px-12 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-50 border border-sky-200 text-sky-800 text-xs font-bold mb-4">
              <CloudSun className="w-3.5 h-3.5 text-sky-600" /> Multi-Modal Data Sources
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Synchronized Weather Stations & Underground Soil Probes
            </h2>
            <p className="mt-4 text-sm text-slate-600 leading-relaxed">
              AgriSense captures environmental context both above and below the soil surface. Ambient weather data is correlated with root-zone volumetric water content, soil temperature, and nutrient chemistry to eliminate guesswork in crop water budgeting.
            </p>

            <div className="mt-6 space-y-3">
              {[
                { title: 'Soil Moisture Sensors', detail: 'Volumetric Water Content (%) with 30-70% optimal baseline.' },
                { title: 'Soil pH & NPK Sensors', detail: 'Real-time Nitrogen, Phosphorus, and Potassium monitoring.' },
                { title: 'Automated Weather Stations', detail: 'Temperature, relative humidity, barometric pressure & precipitation.' },
                { title: 'Solar Radiation & Lux', detail: 'Photoperiod tracking for precise evapotranspiration (ET0) estimation.' },
              ].map((item) => (
                <div key={item.title} className="flex items-start gap-3 p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">{item.title}</h4>
                    <p className="text-xs text-slate-500">{item.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-7 text-white shadow-xl border border-slate-700">
            <div className="flex items-center justify-between pb-4 border-b border-slate-700/80 mb-6">
              <div className="flex items-center gap-2">
                <BrainCircuit className="w-5 h-5 text-emerald-400" />
                <span className="text-xs font-bold tracking-wider uppercase text-emerald-400">Machine Learning Benchmarks</span>
              </div>
              <span className="text-[11px] font-mono text-slate-400">Validated on 4,320 Records</span>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-slate-200">Soil Moisture Regression (Random Forest)</span>
                  <span className="text-xs font-mono text-emerald-400 font-bold">R² = 0.941</span>
                </div>
                <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: '94.1%' }} />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 mt-1.5 font-mono">
                  <span>MAE: 1.42%</span>
                  <span>RMSE: 1.78%</span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-slate-200">Irrigation Classifier (Gradient Boosted Trees)</span>
                  <span className="text-xs font-mono text-sky-400 font-bold">Accuracy = 96.3%</span>
                </div>
                <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div className="bg-sky-500 h-full rounded-full" style={{ width: '96.3%' }} />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 mt-1.5 font-mono">
                  <span>Precision: 95.2%</span>
                  <span>F1-Score: 96.3%</span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-slate-200">Crop Suitability (KNN + Ensemble)</span>
                  <span className="text-xs font-mono text-amber-400 font-bold">Accuracy = 94.8%</span>
                </div>
                <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full" style={{ width: '94.8%' }} />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 mt-1.5 font-mono">
                  <span>Rice, Wheat, Maize, Cotton</span>
                  <span>Recall: 94.9%</span>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-700/80 flex items-center justify-between">
              <span className="text-xs text-slate-400">Zero data fabrication</span>
              <button
                onClick={() => onNavigate('research-analytics')}
                className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
              >
                Inspect Empirical Metrics <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Tech Stack Banner */}
      <section className="bg-slate-100 py-12 px-6 lg:px-12 border-t border-slate-200">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-6">
            Production-Grade Research Architecture
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-4">
            {[
              { title: 'React + Vite', role: 'Frontend SPA' },
              { title: 'Tailwind CSS', role: 'Design System' },
              { title: 'Spring Boot 3', role: 'REST Backend' },
              { title: 'PostgreSQL', role: 'Relational Store' },
              { title: 'FastAPI / Python', role: 'ML Inference' },
              { title: 'Scikit-Learn', role: 'Model Training' },
            ].map((tech) => (
              <div key={tech.title} className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs">
                <p className="text-xs font-bold text-slate-800">{tech.title}</p>
                <p className="text-[10px] text-slate-400">{tech.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-8 px-6 lg:px-12 text-center text-xs text-slate-500">
        <p className="font-semibold text-slate-700">
          Data Analytics for Smart Agriculture Using Weather and Soil Sensor Data
        </p>
        <p className="mt-1 text-[11px] text-slate-400">
          Academic Research Demonstration Platform • Built with PostgreSQL, Spring Boot, Python ML & React SPA
        </p>
      </footer>
    </div>
  );
};
