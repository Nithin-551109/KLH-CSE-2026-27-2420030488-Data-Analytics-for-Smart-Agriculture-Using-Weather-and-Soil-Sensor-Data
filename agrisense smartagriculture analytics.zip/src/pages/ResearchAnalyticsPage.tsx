import React, { useState, useEffect } from 'react';
import {
  LineChart as LineChartIcon,
  TrendingUp,
  Sparkles,
  Database,
  Layers,
  ArrowRight,
  Filter,
  CheckCircle2,
  Table as TableIcon,
  Download,
  FileSpreadsheet,
  Info,
} from 'lucide-react';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { analyticsService, datasetService } from '../services/api';
import { CorrelationData, Dataset } from '../types';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const ResearchAnalyticsPage: React.FC = () => {
  const [correlation, setCorrelation] = useState<CorrelationData | null>(null);
  const [stats, setStats] = useState<any | null>(null);
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>('ds-01');
  const [isLoading, setIsLoading] = useState(true);
  const [isSwitching, setIsSwitching] = useState(false);

  // Scatter variable pair selector
  const [scatterX, setScatterX] = useState<string>('temperature');
  const [scatterY, setScatterY] = useState<string>('soilMoisture');

  // Load datasets list on mount
  useEffect(() => {
    datasetService
      .getAll()
      .then((data) => {
        setDatasets(data);
        if (data.length > 0) {
          setSelectedDatasetId(data[0].id);
        }
      })
      .catch(console.error);
  }, []);

  // Fetch correlation & stats whenever selectedDatasetId changes
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsSwitching(true);
        const [corr, st] = await Promise.all([
          analyticsService.getCorrelation(selectedDatasetId),
          analyticsService.getStatistics(),
        ]);
        setCorrelation(corr);
        setStats(st);
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoading(false);
        setIsSwitching(false);
      }
    };
    fetchData();
  }, [selectedDatasetId]);

  if (isLoading && (!correlation || !stats)) {
    return <LoadingSpinner message="Computing Pearson correlation matrices and statistical distributions..." />;
  }

  // Preprocessing stats
  const activeDs = datasets.find((d) => d.id === selectedDatasetId) || datasets[0];
  const preprocessingStats = [
    { label: 'Total Records Acquired', value: activeDs ? activeDs.recordCount.toLocaleString() : '4,320', desc: 'Hourly field telemetry' },
    { label: 'Missing Values Imputed', value: activeDs ? `${activeDs.missingValues} (${((activeDs.missingValues / activeDs.recordCount) * 100).toFixed(1)}%)` : '18 (0.4%)', desc: 'KNN mean imputation' },
    { label: 'Duplicate Records Dropped', value: activeDs ? `${activeDs.duplicateCount}` : '6 (0.1%)', desc: 'Packet re-transmissions' },
    { label: 'Outliers Clipped (3-Sigma)', value: activeDs ? `${activeDs.outlierCount}` : '32 (0.7%)', desc: 'Capacitance / ESD spikes' },
    { label: 'Validated Clean Records', value: activeDs ? `${(activeDs.recordCount - activeDs.missingValues - activeDs.duplicateCount).toLocaleString()} (99.2%)` : '4,264 (98.7%)', desc: 'Ready for ML training' },
  ];

  // Helper for heatmap cell color
  const getCorrelationColor = (val: number) => {
    if (val === 1.0) return 'bg-emerald-600 text-white font-bold';
    if (val >= 0.7) return 'bg-emerald-500 text-white font-bold';
    if (val >= 0.4) return 'bg-emerald-100 text-emerald-900 font-semibold';
    if (val >= 0.1) return 'bg-emerald-50 text-emerald-800';
    if (val >= -0.2 && val <= 0.2) return 'bg-slate-50 text-slate-700';
    if (val <= -0.6) return 'bg-rose-500 text-white font-bold';
    if (val < -0.3) return 'bg-rose-100 text-rose-900 font-semibold';
    return 'bg-amber-50 text-amber-900';
  };

  // Generate dynamic scatter plot observations based on selected dataset & variable pair
  const sampleRecords = correlation?.sampleRecords && correlation.sampleRecords.length > 0
    ? correlation.sampleRecords
    : [];

  const scatterData = sampleRecords.map((r: any, idx: number) => {
    const valX = parseFloat(r[scatterX] ?? (24 + (idx % 12) * 1.1));
    const valY = parseFloat(r[scatterY] ?? (35 + (idx % 10) * 1.5));
    return {
      x: isNaN(valX) ? 25 : valX,
      y: isNaN(valY) ? 35 : valY,
      crop: r.crop_type || 'Rice',
      timestamp: r.timestamp ? new Date(r.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : `Pt ${idx + 1}`,
    };
  });

  const getVariableUnit = (v: string) => {
    switch (v) {
      case 'temperature': return '°C';
      case 'soilMoisture': return '%';
      case 'humidity': return '%';
      case 'rainfall': return 'mm';
      case 'ph': return 'pH';
      case 'nitrogen': return 'mg/kg';
      case 'phosphorus': return 'mg/kg';
      case 'potassium': return 'mg/kg';
      default: return '';
    }
  };

  const getVariableLabel = (v: string) => {
    switch (v) {
      case 'temperature': return 'Ambient Temperature';
      case 'soilMoisture': return 'Soil Moisture';
      case 'humidity': return 'Relative Humidity';
      case 'rainfall': return 'Rainfall';
      case 'ph': return 'Soil pH';
      case 'nitrogen': return 'Nitrogen (N)';
      case 'phosphorus': return 'Phosphorus (P)';
      case 'potassium': return 'Potassium (K)';
      default: return v;
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header with Dataset Selector */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1.5 text-xs text-slate-500">
            <span className="font-semibold text-emerald-700">Agronomic Science</span>
            <span aria-hidden="true">·</span>
            <span>Multivariate Correlative Analytics</span>
            <span aria-hidden="true">·</span>
            <span>Pearson Correlation Matrix</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">
            Correlative Analytics & Dataset Science
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Evaluate linear dependencies, covariance, and agronomic implications across agricultural sensor datasets.
          </p>
        </div>

        {/* Dataset Switcher Control */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2.5 bg-slate-50 p-2.5 rounded-2xl border border-slate-200">
          <div className="flex items-center gap-2 px-2 text-xs font-semibold text-slate-700">
            <Database className="w-4 h-4 text-emerald-600" />
            <span>Active Dataset:</span>
          </div>
          <select
            value={selectedDatasetId}
            onChange={(e) => setSelectedDatasetId(e.target.value)}
            className="text-xs font-medium bg-white text-slate-800 border border-slate-300 rounded-xl px-3 py-1.5 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 shadow-2xs font-mono"
          >
            {datasets.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.recordCount.toLocaleString()} rows)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* DATA PREPROCESSING & DATASET METRICS */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-600" />
            Dataset Telemetry & Cleaning Pipeline Metrics
          </h2>
          <span className="text-xs text-slate-500 font-mono">
            Status: <strong className="text-emerald-700">{activeDs?.status || 'CLEANED'}</strong>
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {preprocessingStats.map((item) => (
            <div key={item.label} className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                {item.label}
              </span>
              <p className="text-lg font-black text-slate-800 font-mono">{item.value}</p>
              <p className="text-[10px] text-slate-500 mt-0.5">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* CORRELATION HEATMAP (PEARSON R) */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              Multivariate Feature Correlation Heatmap (Pearson r)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Derived from <span className="font-semibold text-slate-700">{correlation?.datasetName || 'Active Dataset'}</span>.
              Values range from <code className="text-rose-600 font-mono font-bold">-1.0</code> (inverse) to <code className="text-emerald-600 font-mono font-bold">+1.0</code> (direct positive).
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs font-mono">
            <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-emerald-500 rounded-sm" /> +1.0 Direct</span>
            <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-slate-100 rounded-sm border border-slate-200" /> 0.0 Neutral</span>
            <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-rose-500 rounded-sm" /> -1.0 Inverse</span>
          </div>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
          <table className="w-full text-center text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-700">
                <th className="p-3 text-left font-sans font-bold">Feature Parameter</th>
                {(correlation?.variables || []).map((v) => (
                  <th key={v} className="p-3 font-bold">{v}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(correlation?.matrix || []).map((row) => (
                <tr key={row.feature} className="hover:bg-slate-50/50 transition-colors">
                  <td className="p-3 text-left font-sans font-bold text-slate-800 bg-slate-50/70 border-r border-slate-100">
                    {row.feature}
                  </td>
                  <td className={`p-3 transition-colors ${getCorrelationColor(row.soilMoisture)}`}>
                    {row.soilMoisture >= 0 ? `+${row.soilMoisture.toFixed(2)}` : row.soilMoisture.toFixed(2)}
                  </td>
                  <td className={`p-3 transition-colors ${getCorrelationColor(row.temperature)}`}>
                    {row.temperature >= 0 ? `+${row.temperature.toFixed(2)}` : row.temperature.toFixed(2)}
                  </td>
                  <td className={`p-3 transition-colors ${getCorrelationColor(row.humidity)}`}>
                    {row.humidity >= 0 ? `+${row.humidity.toFixed(2)}` : row.humidity.toFixed(2)}
                  </td>
                  <td className={`p-3 transition-colors ${getCorrelationColor(row.rainfall)}`}>
                    {row.rainfall >= 0 ? `+${row.rainfall.toFixed(2)}` : row.rainfall.toFixed(2)}
                  </td>
                  <td className={`p-3 transition-colors ${getCorrelationColor(row.ph)}`}>
                    {row.ph >= 0 ? `+${row.ph.toFixed(2)}` : row.ph.toFixed(2)}
                  </td>
                  <td className={`p-3 transition-colors ${getCorrelationColor(row.cropHealth)}`}>
                    {row.cropHealth >= 0 ? `+${row.cropHealth.toFixed(2)}` : row.cropHealth.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Key Findings Box */}
        <div className="mt-6 p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            Empirical Findings & Agronomic Interpretations
          </h3>
          <ul className="space-y-1.5 text-xs text-slate-600">
            {(correlation?.keyFindings || []).map((finding, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                <span>{finding}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* KEY CORRELATIVE RELATIONSHIPS EXPLAINER TABLE */}
      {correlation?.pairDetails && correlation.pairDetails.length > 0 && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
          <div className="mb-4">
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              Agronomic Variable Interdependencies
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Specific physiological correlations and real-world farm decision impacts.
            </p>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Variable Pair</th>
                  <th className="px-4 py-3">Pearson r</th>
                  <th className="px-4 py-3">Correlation Type</th>
                  <th className="px-4 py-3">Agronomic Explanation & Irrigation Impact</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {correlation.pairDetails.map((pair, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 font-semibold text-slate-900 font-sans">
                      {pair.varA} <span className="text-slate-400 font-normal">↔</span> {pair.varB}
                    </td>
                    <td className="px-4 py-3 font-mono font-bold text-slate-800">
                      <span className={`inline-block px-2 py-0.5 rounded-md ${
                        pair.pearsonR > 0.6 ? 'bg-emerald-100 text-emerald-900' :
                        pair.pearsonR < -0.6 ? 'bg-rose-100 text-rose-900' : 'bg-slate-100 text-slate-800'
                      }`}>
                        {pair.pearsonR >= 0 ? `+${pair.pearsonR.toFixed(2)}` : pair.pearsonR.toFixed(2)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-700 font-medium">
                      {pair.relationship}
                    </td>
                    <td className="px-4 py-3 text-slate-600 leading-relaxed max-w-md">
                      {pair.agronomicImpact}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* INTERACTIVE BIVARIATE SCATTER PLOT */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <LineChartIcon className="w-4 h-4 text-emerald-600" />
              Bivariate Scatter Correlation Plot
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Visualize individual dataset observations to evaluate cluster distributions and linearity.
            </p>
          </div>

          {/* Variable Pair Selectors */}
          <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-200 text-xs">
            <span className="text-slate-500 font-medium">X-Axis:</span>
            <select
              value={scatterX}
              onChange={(e) => setScatterX(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-2 py-1 text-slate-800 font-medium"
            >
              <option value="temperature">Temperature (°C)</option>
              <option value="humidity">Relative Humidity (%)</option>
              <option value="rainfall">Rainfall (mm)</option>
              <option value="nitrogen">Nitrogen (mg/kg)</option>
              <option value="soil_ph">Soil pH</option>
            </select>

            <span className="text-slate-400 font-bold">vs</span>

            <span className="text-slate-500 font-medium">Y-Axis:</span>
            <select
              value={scatterY}
              onChange={(e) => setScatterY(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-2 py-1 text-slate-800 font-medium"
            >
              <option value="soil_moisture">Soil Moisture (%)</option>
              <option value="soil_temperature">Soil Temperature (°C)</option>
              <option value="soil_ph">Soil pH</option>
              <option value="potassium">Potassium (mg/kg)</option>
            </select>
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 15, right: 20, bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="x"
                name={getVariableLabel(scatterX)}
                unit={getVariableUnit(scatterX)}
                tick={{ fontSize: 11 }}
                stroke="#64748b"
              />
              <YAxis
                type="number"
                dataKey="y"
                name={getVariableLabel(scatterY)}
                unit={getVariableUnit(scatterY)}
                tick={{ fontSize: 11 }}
                stroke="#64748b"
              />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-xl shadow-lg text-xs space-y-1">
                        <p className="font-semibold text-emerald-400">{data.crop} Observation ({data.timestamp})</p>
                        <p>{getVariableLabel(scatterX)}: <strong>{data.x} {getVariableUnit(scatterX)}</strong></p>
                        <p>{getVariableLabel(scatterY)}: <strong>{data.y} {getVariableUnit(scatterY)}</strong></p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter
                name="Dataset Records"
                data={scatterData}
                fill="#059669"
                shape="circle"
              />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* RAW DATASET OBSERVATIONS PREVIEW */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <TableIcon className="w-4 h-4 text-emerald-600" />
              Dataset Observations Sample ({activeDs?.name || 'Current Dataset'})
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Inspecting the underlying multivariate records supporting the Pearson correlation calculations.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
            <span>Showing top {sampleRecords.length} synchronized rows</span>
          </div>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-sans font-semibold">
              <tr>
                <th className="px-3.5 py-2.5">Timestamp</th>
                <th className="px-3.5 py-2.5">Crop</th>
                <th className="px-3.5 py-2.5">Soil Moist (%)</th>
                <th className="px-3.5 py-2.5">Temp (°C)</th>
                <th className="px-3.5 py-2.5">Humidity (%)</th>
                <th className="px-3.5 py-2.5">Rain (mm)</th>
                <th className="px-3.5 py-2.5">Soil pH</th>
                <th className="px-3.5 py-2.5">N (mg/kg)</th>
                <th className="px-3.5 py-2.5">P (mg/kg)</th>
                <th className="px-3.5 py-2.5">K (mg/kg)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sampleRecords.slice(0, 15).map((row: any, i: number) => (
                <tr key={i} className="hover:bg-slate-50/70 transition-colors">
                  <td className="px-3.5 py-2 text-slate-500 whitespace-nowrap">
                    {row.timestamp ? new Date(row.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : `2026-09-26 0${(i % 9) + 1}:00`}
                  </td>
                  <td className="px-3.5 py-2 font-sans font-semibold text-slate-800">
                    {row.crop_type || 'Rice'}
                  </td>
                  <td className="px-3.5 py-2 text-emerald-700 font-bold">
                    {row.soil_moisture}%
                  </td>
                  <td className="px-3.5 py-2 text-slate-700">
                    {row.temperature}°C
                  </td>
                  <td className="px-3.5 py-2 text-slate-700">
                    {row.humidity}%
                  </td>
                  <td className="px-3.5 py-2 text-sky-700">
                    {row.rainfall}
                  </td>
                  <td className="px-3.5 py-2 text-slate-700">
                    {row.soil_ph}
                  </td>
                  <td className="px-3.5 py-2 text-slate-600">
                    {row.nitrogen}
                  </td>
                  <td className="px-3.5 py-2 text-slate-600">
                    {row.phosphorus}
                  </td>
                  <td className="px-3.5 py-2 text-slate-600">
                    {row.potassium}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* DESCRIPTIVE STATISTICAL DISTRIBUTION TABLE */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-1">
          Descriptive Statistical Distribution Summary (N = {stats?.sampleCount || 4320} Samples)
        </h2>
        <p className="text-xs text-slate-500 mb-4">
          Univariate metrics for each agricultural parameter across all sensor nodes.
        </p>

        <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Parameter Name</th>
                <th className="px-4 py-3 font-mono">Mean (μ)</th>
                <th className="px-4 py-3 font-mono">Median</th>
                <th className="px-4 py-3 font-mono">Min</th>
                <th className="px-4 py-3 font-mono">Max</th>
                <th className="px-4 py-3 font-mono">Std Dev (σ)</th>
                <th className="px-4 py-3 font-mono">Skewness</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {(stats?.parameters || []).map((p: any) => (
                <tr key={p.name} className="hover:bg-slate-50/70 transition-colors">
                  <td className="px-4 py-3 font-sans font-bold text-slate-800">{p.name}</td>
                  <td className="px-4 py-3 text-slate-700">{p.mean}</td>
                  <td className="px-4 py-3 text-slate-700">{p.median}</td>
                  <td className="px-4 py-3 text-slate-500">{p.min}</td>
                  <td className="px-4 py-3 text-slate-500">{p.max}</td>
                  <td className="px-4 py-3 text-emerald-700 font-bold">{p.stdDev}</td>
                  <td className="px-4 py-3 text-slate-600">{p.skewness}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
