import React, { useState, useEffect } from 'react';
import {
  CloudSun,
  Thermometer,
  Droplets,
  Wind,
  Gauge,
  CloudRain,
  Sun,
  CloudLightning,
  CloudDrizzle,
  Calendar,
  MapPin,
  RefreshCw,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import { weatherService, farmService, analyticsService } from '../services/api';
import { WeatherData, Farm } from '../types';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const WeatherAnalyticsPage: React.FC = () => {
  const { selectedFarmId, setSelectedFarmId, liveTick } = useAuth();
  const [farms, setFarms] = useState<Farm[]>([]);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [hourlyTrend, setHourlyTrend] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    farmService.getAll().then(setFarms).catch(console.error);
  }, []);

  const loadWeatherData = async () => {
    try {
      setIsLoading(true);
      const [wth, dash] = await Promise.all([
        weatherService.getWeather(selectedFarmId),
        analyticsService.getDashboard(selectedFarmId, '7 Days'),
      ]);
      setWeather(wth);
      setHourlyTrend(dash.trends);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadWeatherData();
  }, [selectedFarmId, liveTick]);

  const activeFarm = farms.find((f) => f.id === selectedFarmId) || farms[0];

  const getWeatherIcon = (iconName: string) => {
    switch (iconName) {
      case 'sun':
        return <Sun className="w-6 h-6 text-amber-500" />;
      case 'cloud-rain':
        return <CloudRain className="w-6 h-6 text-sky-500" />;
      case 'cloud-lightning':
        return <CloudLightning className="w-6 h-6 text-purple-500" />;
      case 'cloud-drizzle':
        return <CloudDrizzle className="w-6 h-6 text-blue-400" />;
      default:
        return <CloudSun className="w-6 h-6 text-amber-500" />;
    }
  };

  if (isLoading && !weather) {
    return <LoadingSpinner message="Querying microclimate meteorological services..." />;
  }

  return (
    <div className="space-y-6">
      {/* Top Banner & Location Selector */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-sky-700 bg-sky-50 px-2 py-0.5 rounded-full border border-sky-200">
              Weather & Microclimate Station
            </span>
            <span className="text-xs text-slate-400 font-mono">Sensors: Ambient + Barometric + Anemometer</span>
          </div>
          <h2 className="text-xl font-black text-slate-800 tracking-tight">Weather Analytics & Forecasting</h2>
          <p className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
            <MapPin className="w-3.5 h-3.5 text-slate-400" />
            Station: <strong>{activeFarm?.name}</strong> ({activeFarm?.location})
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Select Station:</span>
          <select
            value={selectedFarmId}
            onChange={(e) => setSelectedFarmId(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 cursor-pointer"
          >
            {farms.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* CURRENT WEATHER OVERVIEW CARD */}
      <div className="bg-gradient-to-br from-sky-900 via-sky-800 to-indigo-950 rounded-3xl p-6 text-white shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-sky-700/60">
          <div className="flex items-center gap-4">
            <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20">
              <CloudSun className="w-12 h-12 text-amber-400" />
            </div>
            <div>
              <p className="text-xs font-semibold text-sky-200 uppercase tracking-wider">Current Atmosphere</p>
              <div className="flex items-baseline gap-3">
                <span className="text-4xl sm:text-5xl font-extrabold tracking-tight font-mono">
                  {weather?.temperature} °C
                </span>
                <span className="text-sm font-semibold text-sky-100 px-3 py-1 rounded-full bg-white/10 border border-white/20">
                  {weather?.condition}
                </span>
              </div>
              <p className="text-xs text-sky-300 mt-1">
                Updated: {new Date(weather?.lastUpdated || Date.now()).toLocaleTimeString()} • Local Ground Station
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-3 rounded-xl bg-white/5 border border-white/10">
              <span className="text-[11px] text-sky-300 flex items-center gap-1">
                <Droplets className="w-3.5 h-3.5" /> Relative Humidity
              </span>
              <p className="text-lg font-bold font-mono mt-0.5">{weather?.humidity} %</p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10">
              <span className="text-[11px] text-sky-300 flex items-center gap-1">
                <CloudRain className="w-3.5 h-3.5" /> Daily Rainfall
              </span>
              <p className="text-lg font-bold font-mono mt-0.5">{weather?.rainfall} mm</p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10">
              <span className="text-[11px] text-sky-300 flex items-center gap-1">
                <Wind className="w-3.5 h-3.5" /> Wind Speed
              </span>
              <p className="text-lg font-bold font-mono mt-0.5">{weather?.windSpeed} km/h</p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10">
              <span className="text-[11px] text-sky-300 flex items-center gap-1">
                <Gauge className="w-3.5 h-3.5" /> Barometric Pressure
              </span>
              <p className="text-lg font-bold font-mono mt-0.5">{weather?.pressure} hPa</p>
            </div>
          </div>
        </div>

        {/* 7-DAY EXTENDED FORECAST CARDS */}
        <div className="mt-6">
          <p className="text-xs font-bold uppercase tracking-wider text-sky-300 mb-3 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5" /> 7-Day Precision Agronomic Forecast
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
            {(weather?.forecast || []).map((f) => (
              <div
                key={f.day}
                className="p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-center transition-all"
              >
                <p className="text-xs font-bold text-sky-200">{f.day}</p>
                <p className="text-[10px] text-sky-300/80 mb-2">{f.date}</p>
                <div className="flex justify-center mb-2">{getWeatherIcon(f.icon)}</div>
                <p className="text-xs font-bold font-mono text-white">
                  {f.tempMax}° / <span className="text-sky-300">{f.tempMin}°</span>
                </p>
                <div className="mt-2 text-[10px] text-sky-300 flex items-center justify-center gap-1">
                  <CloudRain className="w-3 h-3 text-sky-400" />
                  <span>{f.rainProb}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* WEATHER CHARTS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Temperature Trend */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">Hourly Ambient Temperature (°C)</h3>
              <p className="text-xs text-slate-400">Canopy sensor telemetry</p>
            </div>
            <span className="text-xs font-mono font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              Min: 21°C • Max: 34°C
            </span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={hourlyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis domain={[18, 38]} tick={{ fontSize: 10 }} stroke="#94a3b8" unit="°C" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff' }} />
                <Line type="monotone" dataKey="temperature" name="Temp (°C)" stroke="#f59e0b" strokeWidth={2.5} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Humidity Trend */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">Relative Humidity Trend (%)</h3>
              <p className="text-xs text-slate-400">Atmospheric moisture content</p>
            </div>
            <span className="text-xs font-mono font-bold text-sky-600 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
              Mean: 64%
            </span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hourlyTrend}>
                <defs>
                  <linearGradient id="humGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#0284c7" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis domain={[30, 95]} tick={{ fontSize: 10 }} stroke="#94a3b8" unit="%" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff' }} />
                <Area type="monotone" dataKey="humidity" name="Humidity (%)" stroke="#0284c7" fill="url(#humGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Precipitation Bar Chart */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">Rainfall Accumulation (mm)</h3>
              <p className="text-xs text-slate-400">Recorded precipitation per interval</p>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={hourlyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis tick={{ fontSize: 10 }} stroke="#94a3b8" unit=" mm" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff' }} />
                <Bar dataKey="rainfall" name="Rainfall (mm)" fill="#0284c7" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Temperature vs Humidity Coupling */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">Vapor Pressure Deficit (VPD) Proxy</h3>
              <p className="text-xs text-slate-400">Coupled inverse correlation between Temp and Humidity</p>
            </div>
            <span className="text-xs font-mono text-emerald-600 font-bold">r = -0.82</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={hourlyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis yAxisId="t" domain={[15, 40]} tick={{ fontSize: 10 }} stroke="#f59e0b" unit="°C" />
                <YAxis yAxisId="h" orientation="right" domain={[30, 100]} tick={{ fontSize: 10 }} stroke="#0284c7" unit="%" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line yAxisId="t" type="monotone" dataKey="temperature" name="Temp (°C)" stroke="#f59e0b" strokeWidth={2} />
                <Line yAxisId="h" type="monotone" dataKey="humidity" name="Humidity (%)" stroke="#0284c7" strokeWidth={2} strokeDasharray="3 3" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
