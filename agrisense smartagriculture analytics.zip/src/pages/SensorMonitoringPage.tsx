import React, { useState, useEffect } from 'react';
import {
  Radio,
  RefreshCw,
  Search,
  Filter,
  Eye,
  Sliders,
  Battery,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  MapPin,
  Clock,
  Sparkles,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import { sensorService, farmService } from '../services/api';
import { Sensor, Farm } from '../types';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const SensorMonitoringPage: React.FC = () => {
  const { selectedFarmId, setSelectedFarmId, liveTick, triggerLivePulse } = useAuth();
  const [sensors, setSensors] = useState<Sensor[]>([]);
  const [farms, setFarms] = useState<Farm[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Details Modal
  const [activeSensor, setActiveSensor] = useState<Sensor | null>(null);
  const [sensorDetails, setSensorDetails] = useState<any | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [manualValue, setManualValue] = useState('');

  useEffect(() => {
    farmService.getAll().then(setFarms).catch(console.error);
  }, []);

  const loadSensors = async () => {
    try {
      setIsLoading(true);
      const res = await sensorService.getAll({ farmId: selectedFarmId });
      setSensors(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSensors();
  }, [selectedFarmId, liveTick]);

  const handleOpenDetails = async (sensor: Sensor) => {
    setActiveSensor(sensor);
    setShowModal(true);
    setManualValue(sensor.currentValue.toString());
    try {
      const details = await sensorService.getById(sensor.id);
      setSensorDetails(details);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSimulateValue = async () => {
    if (!activeSensor || !manualValue) return;
    try {
      await sensorService.addReading(activeSensor.id, Number(manualValue));
      triggerLivePulse();
      // Reload details
      const details = await sensorService.getById(activeSensor.id);
      setSensorDetails(details);
      setActiveSensor({ ...activeSensor, currentValue: Number(manualValue) });
    } catch (err) {
      alert('Failed to transmit simulated telemetry reading.');
    }
  };

  const filteredSensors = sensors.filter((s) => {
    const matchesSearch = s.type.toLowerCase().includes(search.toLowerCase()) || s.id.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || s.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-800 tracking-tight">Sensor Monitoring Hub</h2>
          <p className="text-xs text-slate-500">
            Real-time telemetry streams from 9 in-situ probe categories with edge telemetry verification
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => triggerLivePulse()}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Simulate Real-Time Pulse
          </button>
        </div>
      </div>

      {/* Filter and Farm Selector */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search sensor type or ID..."
            className="w-full pl-9 pr-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-500 font-medium">Farm:</span>
            <select
              value={selectedFarmId}
              onChange={(e) => setSelectedFarmId(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800 cursor-pointer"
            >
              {farms.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-xs text-slate-500 font-medium">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-800 cursor-pointer"
            >
              <option value="ALL">All Statuses</option>
              <option value="ONLINE">ONLINE</option>
              <option value="WARNING">WARNING</option>
              <option value="OFFLINE">OFFLINE</option>
            </select>
          </div>
        </div>
      </div>

      {/* Sensor Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {isLoading ? (
          <LoadingSpinner message="Polling live IoT sensor endpoints..." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
                <tr>
                  <th className="px-4 py-3.5">Sensor ID</th>
                  <th className="px-4 py-3.5">Sensor Type</th>
                  <th className="px-4 py-3.5">Placement / Depth</th>
                  <th className="px-4 py-3.5">Current Value</th>
                  <th className="px-4 py-3.5">Operating Range</th>
                  <th className="px-4 py-3.5">Battery</th>
                  <th className="px-4 py-3.5">Status</th>
                  <th className="px-4 py-3.5">Last Stream</th>
                  <th className="px-4 py-3.5 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredSensors.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 font-mono text-slate-400 font-semibold">{s.id}</td>
                    <td className="px-4 py-3 font-bold text-slate-800">
                      <div className="flex items-center gap-2">
                        <Radio className="w-3.5 h-3.5 text-emerald-600" />
                        {s.type}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-500">{s.depthOrHeight || 'Root zone'}</td>
                    <td className="px-4 py-3">
                      <span className="font-mono font-black text-sm text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        {s.currentValue} {s.unit}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-400">
                      {s.minNormal} - {s.maxNormal} {s.unit}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 font-mono text-slate-600">
                        <Battery className="w-3.5 h-3.5 text-emerald-500" />
                        {s.batteryLevel}%
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge
                        variant={s.status === 'ONLINE' ? 'green' : s.status === 'WARNING' ? 'amber' : 'red'}
                        size="sm"
                        dot
                      >
                        {s.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-slate-400 font-mono">
                      {new Date(s.lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => handleOpenDetails(s)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 rounded-lg transition-colors font-semibold"
                      >
                        <Eye className="w-3.5 h-3.5" /> Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* SENSOR INSPECTION & SIMULATION MODAL */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={activeSensor?.type || 'Sensor Inspector'}
        subtitle={`Sensor ID: ${activeSensor?.id} • Deployment: ${activeSensor?.depthOrHeight}`}
        maxWidth="2xl"
      >
        <div className="space-y-5 text-xs">
          {/* Real-time stats card */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold">Current Value</span>
              <p className="text-xl font-black text-emerald-700 font-mono mt-0.5">
                {activeSensor?.currentValue} {activeSensor?.unit}
              </p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold">Historical Average</span>
              <p className="text-xl font-black text-slate-800 font-mono mt-0.5">
                {sensorDetails?.statistics?.avg ?? activeSensor?.currentValue} {activeSensor?.unit}
              </p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold">Historical Min / Max</span>
              <p className="text-sm font-bold text-slate-800 font-mono mt-1">
                {sensorDetails?.statistics?.min} / {sensorDetails?.statistics?.max} {activeSensor?.unit}
              </p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold">Sensor Health</span>
              <div className="mt-1">
                <Badge variant={activeSensor?.status === 'ONLINE' ? 'green' : 'amber'} size="sm" dot>
                  {activeSensor?.status}
                </Badge>
              </div>
            </div>
          </div>

          {/* Historical Trend Chart */}
          <div className="p-4 bg-white rounded-xl border border-slate-200">
            <h4 className="font-bold text-slate-800 mb-2">Historical Telemetry Curve (Recent Readings)</h4>
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sensorDetails?.recentReadings || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="timestamp" tick={{ fontSize: 9 }} stroke="#94a3b8" tickFormatter={(t) => t.slice(11, 16)} />
                  <YAxis tick={{ fontSize: 9 }} stroke="#94a3b8" unit={` ${activeSensor?.unit}`} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff', fontSize: '11px' }} />
                  <Line type="monotone" dataKey="value" stroke="#10b981" strokeWidth={2} dot={{ r: 2 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Manual Telemetry Injection Simulator */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <h4 className="font-bold text-slate-800">Inject Simulated Sensor Telemetry Pulse</h4>
            </div>
            <p className="text-[11px] text-slate-500 mb-3">
              Transmit an experimental sensor value to test real-time threshold breaches, alert triggers, and ML recalculations.
            </p>
            <div className="flex items-center gap-3">
              <input
                type="number"
                step="0.1"
                value={manualValue}
                onChange={(e) => setManualValue(e.target.value)}
                placeholder="Enter value..."
                className="w-36 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold"
              />
              <span className="font-mono text-xs text-slate-600">{activeSensor?.unit}</span>
              <button
                type="button"
                onClick={handleSimulateValue}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-xs transition-colors"
              >
                Transmit Pulse
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};
