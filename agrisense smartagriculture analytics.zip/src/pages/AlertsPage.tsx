import React, { useState, useEffect } from 'react';
import {
  BellRing,
  AlertTriangle,
  CheckCircle2,
  Filter,
  Plus,
  Search,
  Check,
  MapPin,
  Clock,
  ShieldAlert,
} from 'lucide-react';
import { alertService, farmService } from '../services/api';
import { Alert, Farm } from '../types';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { useAuth } from '../context/AuthContext';

export const AlertsPage: React.FC = () => {
  const { user, liveTick, triggerLivePulse } = useAuth();
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [farms, setFarms] = useState<Farm[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [severityFilter, setSeverityFilter] = useState('ALL');

  // New alert modal
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    farmId: '',
    type: 'LOW SOIL MOISTURE',
    severity: 'WARNING' as Alert['severity'],
    message: '',
  });

  const loadAlerts = async () => {
    try {
      setIsLoading(true);
      const [res, fList] = await Promise.all([alertService.getAll(), farmService.getAll()]);
      setAlerts(res);
      setFarms(fList);
      if (fList.length > 0 && !formData.farmId) {
        setFormData((prev) => ({ ...prev, farmId: fList[0].id }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAlerts();
  }, [liveTick]);

  const handleResolve = async (id: string) => {
    try {
      await alertService.resolve(id, user?.name || 'Administrator');
      triggerLivePulse();
      loadAlerts();
    } catch (err) {
      alert('Failed to resolve alert.');
    }
  };

  const handleCreateAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await alertService.create(formData);
      setShowModal(false);
      setFormData({ farmId: farms[0]?.id || '', type: 'LOW SOIL MOISTURE', severity: 'WARNING', message: '' });
      triggerLivePulse();
      loadAlerts();
    } catch (err) {
      alert('Failed to create manual alert.');
    }
  };

  const filteredAlerts = alerts.filter((a) => {
    const matchesSearch =
      a.message.toLowerCase().includes(search.toLowerCase()) ||
      a.type.toLowerCase().includes(search.toLowerCase()) ||
      a.farmName.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || a.status === statusFilter;
    const matchesSeverity = severityFilter === 'ALL' || a.severity === severityFilter;
    return matchesSearch && matchesStatus && matchesSeverity;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-800 tracking-tight">Agricultural Alert Center</h2>
          <p className="text-xs text-slate-500">
            Real-time anomaly detection, threshold breaches, and actionable field notifications
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" /> Trigger Custom Alert
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search alert type, message, farm..."
            className="w-full pl-9 pr-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto flex-wrap">
          <div className="flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-xs text-slate-500 font-medium">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800 cursor-pointer"
            >
              <option value="ALL">All Statuses</option>
              <option value="ACTIVE">ACTIVE</option>
              <option value="RESOLVED">RESOLVED</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-500 font-medium">Severity:</span>
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800 cursor-pointer"
            >
              <option value="ALL">All Severities</option>
              <option value="CRITICAL">CRITICAL</option>
              <option value="WARNING">WARNING</option>
              <option value="INFO">INFO</option>
            </select>
          </div>
        </div>
      </div>

      {/* Alerts Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {isLoading ? (
          <LoadingSpinner message="Loading active agricultural alerts..." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
                <tr>
                  <th className="px-4 py-3.5">Alert ID</th>
                  <th className="px-4 py-3.5">Severity</th>
                  <th className="px-4 py-3.5">Alert Type</th>
                  <th className="px-4 py-3.5">Target Farm</th>
                  <th className="px-4 py-3.5">Message / Agronomic Impact</th>
                  <th className="px-4 py-3.5">Triggered Time</th>
                  <th className="px-4 py-3.5">Status</th>
                  <th className="px-4 py-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAlerts.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 font-mono text-slate-400 font-semibold">{a.id}</td>
                    <td className="px-4 py-3">
                      <Badge
                        variant={a.severity === 'CRITICAL' ? 'red' : a.severity === 'WARNING' ? 'amber' : 'blue'}
                        size="sm"
                        dot
                      >
                        {a.severity}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-800">{a.type}</td>
                    <td className="px-4 py-3 text-slate-600">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {a.farmName}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-700 max-w-md">{a.message}</td>
                    <td className="px-4 py-3 text-slate-400 font-mono">
                      {new Date(a.timestamp).toLocaleString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`font-semibold ${
                          a.status === 'ACTIVE' ? 'text-rose-600' : 'text-emerald-600'
                        }`}
                      >
                        {a.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      {a.status === 'ACTIVE' ? (
                        <button
                          onClick={() => handleResolve(a.id)}
                          className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-lg border border-emerald-200 transition-colors"
                        >
                          <Check className="w-3.5 h-3.5" /> Mark Resolved
                        </button>
                      ) : (
                        <span className="text-slate-400 text-[11px] font-medium">
                          Resolved by {a.resolvedBy || 'Admin'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* CREATE ALERT MODAL */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title="Broadcast Field Alert"
        subtitle="Manually dispatch an agronomic alert or testing threshold trigger"
      >
        <form onSubmit={handleCreateAlert} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Target Farm</label>
            <select
              value={formData.farmId}
              onChange={(e) => setFormData({ ...formData, farmId: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold"
            >
              {farms.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Alert Category</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
              >
                <option value="LOW SOIL MOISTURE">LOW SOIL MOISTURE</option>
                <option value="HIGH TEMPERATURE">HIGH TEMPERATURE</option>
                <option value="HEAVY RAINFALL">HEAVY RAINFALL</option>
                <option value="SENSOR OFFLINE">SENSOR OFFLINE</option>
                <option value="ABNORMAL SOIL PH">ABNORMAL SOIL PH</option>
                <option value="LOW NITROGEN">LOW NITROGEN</option>
                <option value="IRRIGATION REQUIRED">IRRIGATION REQUIRED</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Severity</label>
              <select
                value={formData.severity}
                onChange={(e) => setFormData({ ...formData, severity: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold"
              >
                <option value="WARNING">WARNING</option>
                <option value="CRITICAL">CRITICAL</option>
                <option value="INFO">INFO</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Description / Advisory Message</label>
            <textarea
              rows={3}
              required
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="e.g. Moisture dropped below 22% in root zone Sector 3; start irrigation."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setShowModal(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl"
            >
              Dispatch Alert
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
