import React, { useState, useEffect } from 'react';
import {
  Activity,
  Droplets,
  Thermometer,
  Layers,
  Sparkles,
  AlertCircle,
  CheckCircle,
  HelpCircle,
  MapPin,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import { soilService, farmService } from '../services/api';
import { SoilData, Farm } from '../types';
import { Badge } from '../components/common/Badge';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const SoilAnalyticsPage: React.FC = () => {
  const { selectedFarmId, setSelectedFarmId, liveTick } = useAuth();
  const [farms, setFarms] = useState<Farm[]>([]);
  const [soil, setSoil] = useState<SoilData | null>(null);
  const [analytics, setAnalytics] = useState<{
    moistureTrend: any[];
    phTrend: any[];
    distribution: any[];
  } | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    farmService.getAll().then(setFarms).catch(console.error);
  }, []);

  const loadSoilData = async () => {
    try {
      setIsLoading(true);
      const [sl, an] = await Promise.all([
        soilService.getSoilData(selectedFarmId),
        soilService.getSoilAnalytics(selectedFarmId),
      ]);
      setSoil(sl);
      setAnalytics(an);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSoilData();
  }, [selectedFarmId, liveTick]);

  const activeFarm = farms.find((f) => f.id === selectedFarmId) || farms[0];

  if (isLoading && !soil) {
    return <LoadingSpinner message="Retrieving subterranean capacitance & electrochemical sensor readings..." />;
  }

  const conditionColors = {
    DRY: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', badge: 'amber' as const },
    OPTIMAL: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', badge: 'green' as const },
    WET: { bg: 'bg-sky-50', text: 'text-sky-700', border: 'border-sky-200', badge: 'blue' as const },
    CRITICAL: { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200', badge: 'red' as const },
  };

  const currentCondition = soil?.condition || 'OPTIMAL';
  const condStyle = conditionColors[currentCondition];

  const npkComparisonData = [
    { nutrient: 'Nitrogen (N)', current: soil?.nitrogen || 52, benchmark: 60, status: (soil?.nitrogen || 52) < 40 ? 'Deficit' : 'Optimal' },
    { nutrient: 'Phosphorus (P)', current: soil?.phosphorus || 34, benchmark: 35, status: 'Optimal' },
    { nutrient: 'Potassium (K)', current: soil?.potassium || 48, benchmark: 50, status: 'Optimal' },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              Subterranean Telemetry
            </span>
            <span className="text-xs text-slate-400 font-mono">Depth: 15cm & 30cm root zones</span>
          </div>
          <h2 className="text-xl font-black text-slate-800 tracking-tight">Soil Physics & Chemistry Analytics</h2>
          <p className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
            <MapPin className="w-3.5 h-3.5 text-slate-400" />
            Farm: <strong>{soil?.farmName}</strong> • Classification: <strong>{soil?.soilType}</strong>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Select Plot:</span>
          <select
            value={selectedFarmId}
            onChange={(e) => setSelectedFarmId(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 cursor-pointer"
          >
            {farms.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* DYNAMIC SOIL CONDITION CATEGORIZATION CARD (Driven by backend thresholds) */}
      <div className={`p-5 rounded-2xl border ${condStyle.bg} ${condStyle.border} flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs`}>
        <div className="flex items-center gap-3.5">
          <div className={`p-3 rounded-xl bg-white shadow-2xs ${condStyle.text}`}>
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Soil Moisture Status Classification
              </span>
              <Badge variant={condStyle.badge} size="sm" dot>
                {currentCondition}
              </Badge>
            </div>
            <h3 className="text-base font-extrabold text-slate-800 mt-0.5">
              Current Moisture: {soil?.moisture}% (Thresholds: Min {soil?.thresholds.minMoisture}% - Max {soil?.thresholds.maxMoisture}%)
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              {currentCondition === 'DRY'
                ? 'Soil moisture is below configured minimum agronomic threshold. Irrigation recommended.'
                : currentCondition === 'WET'
                ? 'Soil moisture exceeds optimal capacity; waterlogging risk detected. Delay irrigation.'
                : currentCondition === 'CRITICAL'
                ? 'Critical root-zone dehydration detected. Severe plant wilting imminent without prompt watering.'
                : 'Soil moisture is in the optimal range for healthy vegetative growth and nutrient transport.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono font-semibold text-slate-700 bg-white/80 px-4 py-2 rounded-xl border border-slate-200">
          <span>&lt;{soil?.thresholds.minMoisture}% Dry</span>
          <span>•</span>
          <span className="text-emerald-700 font-bold">{soil?.thresholds.minMoisture}-{soil?.thresholds.maxMoisture}% Optimal</span>
          <span>•</span>
          <span>&gt;{soil?.thresholds.maxMoisture}% Wet</span>
        </div>
      </div>

      {/* METRIC SENSOR GAUGES (Moisture, Temp, pH, N, P, K, EC, Organic Matter) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
            <Droplets className="w-4 h-4 text-emerald-500" /> Soil Moisture
          </span>
          <p className="text-2xl font-black text-slate-800 font-mono mt-2">{soil?.moisture} %</p>
          <p className="text-[10px] text-slate-400 mt-1">Target: {soil?.thresholds.minMoisture}% - {soil?.thresholds.maxMoisture}%</p>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
            <Thermometer className="w-4 h-4 text-amber-500" /> Soil Temperature
          </span>
          <p className="text-2xl font-black text-slate-800 font-mono mt-2">{soil?.temperature} °C</p>
          <p className="text-[10px] text-slate-400 mt-1">Nominal: 22°C - 30°C</p>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-purple-500" /> Soil Acidity (pH)
          </span>
          <p className="text-2xl font-black text-slate-800 font-mono mt-2">{soil?.ph}</p>
          <p className="text-[10px] text-slate-400 mt-1">Target: {soil?.thresholds.minPh} - {soil?.thresholds.maxPh} pH</p>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-sky-500" /> Electrical Conductivity
          </span>
          <p className="text-2xl font-black text-slate-800 font-mono mt-2">{soil?.electricalConductivity} dS/m</p>
          <p className="text-[10px] text-slate-400 mt-1">Salinity: Non-saline (&lt; 2 dS/m)</p>
        </div>
      </div>

      {/* CHARTS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Soil Moisture vs Time */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">Soil Moisture vs Time</h3>
              <p className="text-xs text-slate-400">Capacitance sensor historical drying cycle</p>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Optimal Band
            </span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={analytics?.moistureTrend || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis domain={[15, 80]} tick={{ fontSize: 10 }} stroke="#94a3b8" unit="%" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff' }} />
                <Line type="monotone" dataKey="value" name="Moisture (%)" stroke="#10b981" strokeWidth={2.5} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Soil pH vs Time */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">Soil pH Dynamics vs Time</h3>
              <p className="text-xs text-slate-400">Fluctuations from microbial activity and irrigation</p>
            </div>
            <span className="text-xs font-mono text-slate-500 font-semibold">Buffered Loam</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={analytics?.phTrend || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis domain={[5.5, 8.0]} tick={{ fontSize: 10 }} stroke="#94a3b8" unit=" pH" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff' }} />
                <Line type="monotone" dataKey="value" name="pH Level" stroke="#8b5cf6" strokeWidth={2.5} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* NPK Comparison */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">NPK Macronutrient Balance</h3>
              <p className="text-xs text-slate-400">Current levels vs Agronomic reference guidelines</p>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={npkComparisonData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="nutrient" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                <YAxis tick={{ fontSize: 10 }} stroke="#94a3b8" unit=" mg/kg" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Bar dataKey="current" name="Field Current" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="benchmark" name="Agronomic Target" fill="#cbd5e1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Moisture Distribution Classification */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">Soil Condition Historical Distribution</h3>
              <p className="text-xs text-slate-400">Percentage of readings falling in respective agronomic brackets</p>
            </div>
          </div>
          <div className="h-64 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={analytics?.distribution || []}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="count"
                  label={({ name, percent }) => `${name} ${((percent || 0) * 100).toFixed(0)}%`}
                >
                  <Cell fill="#10b981" />
                  <Cell fill="#f59e0b" />
                  <Cell fill="#0284c7" />
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
