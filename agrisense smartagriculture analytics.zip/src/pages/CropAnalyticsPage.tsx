import React, { useState } from 'react';
import {
  Wheat,
  Calendar,
  Droplets,
  Thermometer,
  HeartPulse,
  Sparkles,
  Layers,
  ArrowRight,
  ShieldAlert,
  CheckCircle2,
} from 'lucide-react';
import { Badge } from '../components/common/Badge';

interface CropProfile {
  id: string;
  name: string;
  scientificName: string;
  category: 'Cereal' | 'Cash Crop' | 'Horticulture' | 'Legume';
  growthStage: string;
  stageProgressPct: number;
  plantingDate: string;
  expectedHarvestDate: string;
  daysToHarvest: number;
  waterRequirementDailyMm: number;
  optimalTempRange: string;
  optimalPhRange: string;
  healthScore: number;
  healthStatus: 'Excellent' | 'Good' | 'Under Stress' | 'Critical';
  soilCompatibility: string;
  recommendedCare: string;
}

const CROPS_DATA: CropProfile[] = [
  {
    id: 'crop-1',
    name: 'Rice (Paddy - BPT 5204)',
    scientificName: 'Oryza sativa',
    category: 'Cereal',
    growthStage: 'Tillering Stage',
    stageProgressPct: 45,
    plantingDate: '2026-07-15',
    expectedHarvestDate: '2026-11-20',
    daysToHarvest: 56,
    waterRequirementDailyMm: 7.5,
    optimalTempRange: '22°C – 34°C',
    optimalPhRange: '6.0 – 7.2',
    healthScore: 86,
    healthStatus: 'Good',
    soilCompatibility: 'Loam / Clay Loam',
    recommendedCare: 'Maintain shallow standing water layer (2-5 cm) to suppress weed growth during tillering.',
  },
  {
    id: 'crop-2',
    name: 'Wheat (HD-2967)',
    scientificName: 'Triticum aestivum',
    category: 'Cereal',
    growthStage: 'Grain Filling',
    stageProgressPct: 78,
    plantingDate: '2025-11-10',
    expectedHarvestDate: '2026-04-10',
    daysToHarvest: 18,
    waterRequirementDailyMm: 4.8,
    optimalTempRange: '18°C – 28°C',
    optimalPhRange: '6.2 – 7.5',
    healthScore: 92,
    healthStatus: 'Excellent',
    soilCompatibility: 'Alluvial Loam',
    recommendedCare: 'Terminal irrigation applied; protect against untimely spring rainfall to avoid lodging.',
  },
  {
    id: 'crop-3',
    name: 'Bt Cotton (Hybrid)',
    scientificName: 'Gossypium hirsutum',
    category: 'Cash Crop',
    growthStage: 'Flowering & Boll Formation',
    stageProgressPct: 52,
    plantingDate: '2026-06-01',
    expectedHarvestDate: '2026-12-15',
    daysToHarvest: 81,
    waterRequirementDailyMm: 5.5,
    optimalTempRange: '24°C – 35°C',
    optimalPhRange: '6.5 – 8.0',
    healthScore: 68,
    healthStatus: 'Under Stress',
    soilCompatibility: 'Deep Black Soil (Vertisol)',
    recommendedCare: 'Foliar spray of 1% Potassium Nitrate suggested to alleviate mid-season nutrient depletion.',
  },
  {
    id: 'crop-4',
    name: 'Hybrid Maize (DKC 9108)',
    scientificName: 'Zea mays',
    category: 'Cereal',
    growthStage: 'Vegetative V8',
    stageProgressPct: 35,
    plantingDate: '2026-08-01',
    expectedHarvestDate: '2026-11-30',
    daysToHarvest: 66,
    waterRequirementDailyMm: 6.2,
    optimalTempRange: '20°C – 32°C',
    optimalPhRange: '6.0 – 7.0',
    healthScore: 84,
    healthStatus: 'Good',
    soilCompatibility: 'Well-drained Sandy Loam',
    recommendedCare: 'Side-dressing nitrogen fertilizer prior to tassel emergence; scout for fall armyworm.',
  },
  {
    id: 'crop-5',
    name: 'Tomato (Arka Rakshak)',
    scientificName: 'Solanum lycopersicum',
    category: 'Horticulture',
    growthStage: 'Fruiting Stage',
    stageProgressPct: 62,
    plantingDate: '2026-07-01',
    expectedHarvestDate: '2026-10-25',
    daysToHarvest: 30,
    waterRequirementDailyMm: 5.0,
    optimalTempRange: '21°C – 30°C',
    optimalPhRange: '6.0 – 6.8',
    healthScore: 90,
    healthStatus: 'Excellent',
    soilCompatibility: 'Rich Organic Loam',
    recommendedCare: 'Maintain consistent drip irrigation to avoid blossom end rot caused by calcium fluctuation.',
  },
  {
    id: 'crop-6',
    name: 'Chilli (Guntur Sannam)',
    scientificName: 'Capsicum annuum',
    category: 'Horticulture',
    growthStage: 'Pod Setting',
    stageProgressPct: 58,
    plantingDate: '2026-06-20',
    expectedHarvestDate: '2026-11-15',
    daysToHarvest: 51,
    waterRequirementDailyMm: 4.5,
    optimalTempRange: '22°C – 33°C',
    optimalPhRange: '6.2 – 7.2',
    healthScore: 82,
    healthStatus: 'Good',
    soilCompatibility: 'Sandy Loam with organic mulch',
    recommendedCare: 'Avoid moisture stagnation around collar roots; light, frequent irrigation cycles preferred.',
  },
  {
    id: 'crop-7',
    name: 'Groundnut (K6 - Kadiri 6)',
    scientificName: 'Arachis hypogaea',
    category: 'Legume',
    growthStage: 'Peg Penetration',
    stageProgressPct: 48,
    plantingDate: '2026-07-10',
    expectedHarvestDate: '2026-11-05',
    daysToHarvest: 41,
    waterRequirementDailyMm: 4.2,
    optimalTempRange: '24°C – 32°C',
    optimalPhRange: '6.0 – 7.0',
    healthScore: 88,
    healthStatus: 'Good',
    soilCompatibility: 'Friable Sandy Loam',
    recommendedCare: 'Apply Gypsum (200 kg/ha) around pegging zone to promote high pod shell filling.',
  },
];

export const CropAnalyticsPage: React.FC = () => {
  const [selectedCrop, setSelectedCrop] = useState<CropProfile>(CROPS_DATA[0]);

  const getHealthBadge = (status: CropProfile['healthStatus']) => {
    switch (status) {
      case 'Excellent':
        return <Badge variant="green" size="sm" dot>Excellent</Badge>;
      case 'Good':
        return <Badge variant="blue" size="sm" dot>Good</Badge>;
      case 'Under Stress':
        return <Badge variant="amber" size="sm" dot>Under Stress</Badge>;
      case 'Critical':
        return <Badge variant="red" size="sm" dot>Critical</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-black text-slate-800 tracking-tight">Crop Phenology & Health Analytics</h2>
        <p className="text-xs text-slate-500">
          Growth stages, soil suitability benchmarks, water requirements and crop physiological health indexes
        </p>
      </div>

      {/* Main Grid: Crop Selector Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {CROPS_DATA.map((crop) => {
          const isSelected = selectedCrop.id === crop.id;
          return (
            <div
              key={crop.id}
              onClick={() => setSelectedCrop(crop)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-emerald-50/70 border-emerald-400 shadow-md ring-2 ring-emerald-500/20'
                  : 'bg-white border-slate-200/80 hover:border-slate-300 hover:shadow-xs'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{crop.category}</span>
                {getHealthBadge(crop.healthStatus)}
              </div>

              <h3 className="text-sm font-bold text-slate-800 line-clamp-1">{crop.name}</h3>
              <p className="text-[11px] text-slate-400 italic line-clamp-1">{crop.scientificName}</p>

              {/* Progress bar */}
              <div className="mt-3">
                <div className="flex justify-between text-[10px] font-semibold text-slate-600 mb-1">
                  <span>{crop.growthStage}</span>
                  <span>{crop.stageProgressPct}%</span>
                </div>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      crop.healthScore > 80 ? 'bg-emerald-500' : crop.healthScore > 70 ? 'bg-sky-500' : 'bg-amber-500'
                    }`}
                    style={{ width: `${crop.stageProgressPct}%` }}
                  />
                </div>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Harvest in:</span>
                <span className="font-mono font-bold text-slate-700">{crop.daysToHarvest} days</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* SELECTED CROP DETAILED PROFILE CARD */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-100">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <Wheat className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-slate-800">{selectedCrop.name}</h3>
                {getHealthBadge(selectedCrop.healthStatus)}
              </div>
              <p className="text-xs text-slate-400 italic">{selectedCrop.scientificName} • {selectedCrop.category}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-[10px] font-semibold uppercase text-slate-400">Crop Health Score</span>
              <p className="text-2xl font-black text-emerald-700 font-mono">{selectedCrop.healthScore} / 100</p>
            </div>
          </div>
        </div>

        {/* Phenology Parameters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80">
            <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
              <Droplets className="w-4 h-4 text-sky-500" /> Daily Water Requirement
            </span>
            <p className="text-xl font-black text-slate-800 font-mono mt-1.5">
              {selectedCrop.waterRequirementDailyMm} mm/day
            </p>
            <p className="text-[10px] text-slate-400 mt-1">Calculated via crop coefficient Kc</p>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80">
            <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
              <Thermometer className="w-4 h-4 text-amber-500" /> Thermal Suitability
            </span>
            <p className="text-xl font-black text-slate-800 font-mono mt-1.5">
              {selectedCrop.optimalTempRange}
            </p>
            <p className="text-[10px] text-slate-400 mt-1">Optimal physiological band</p>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80">
            <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-purple-500" /> Soil pH Suitability
            </span>
            <p className="text-xl font-black text-slate-800 font-mono mt-1.5">
              {selectedCrop.optimalPhRange} pH
            </p>
            <p className="text-[10px] text-slate-400 mt-1">Recommended: {selectedCrop.soilCompatibility}</p>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80">
            <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-emerald-500" /> Season Timeline
            </span>
            <p className="text-sm font-bold text-slate-800 mt-1">
              Planted: {selectedCrop.plantingDate}
            </p>
            <p className="text-xs font-bold text-emerald-700 mt-0.5">
              Harvest: {selectedCrop.expectedHarvestDate}
            </p>
          </div>
        </div>

        {/* Agronomic Recommendations Box */}
        <div className="mt-6 p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200">
          <div className="flex items-center gap-2 mb-1.5">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <h4 className="text-xs font-bold text-emerald-950 uppercase tracking-wider">
              Agronomic Advisory & Care Guidelines
            </h4>
          </div>
          <p className="text-xs text-emerald-900 leading-relaxed font-medium">
            {selectedCrop.recommendedCare}
          </p>
        </div>
      </div>
    </div>
  );
};
