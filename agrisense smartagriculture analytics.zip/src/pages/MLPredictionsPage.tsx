import React, { useState, useEffect } from 'react';
import {
  BrainCircuit,
  Sliders,
  Send,
  Sparkles,
  Layers,
  Activity,
  Droplets,
  Wheat,
  CheckCircle2,
  TrendingUp,
  BarChart3,
  Cpu,
} from 'lucide-react';
import { mlService } from '../services/api';
import { Badge } from '../components/common/Badge';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const MLPredictionsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'moisture' | 'irrigation' | 'suitability' | 'health' | 'benchmarks'>('moisture');
  const [benchmarks, setBenchmarks] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Form states for each model
  // 1. Soil Moisture Forecaster
  const [moistureForm, setMoistureForm] = useState({
    temperature: 31,
    humidity: 62,
    rainfall: 0,
    currentMoisture: 36,
    daysAhead: 2,
  });
  const [moistureResult, setMoistureResult] = useState<any | null>(null);

  // 2. Irrigation Classifier
  const [irrigationForm, setIrrigationForm] = useState({
    soilMoisture: 27,
    temperature: 33,
    humidity: 55,
    rainfallForecast: 0,
    cropType: 'Rice',
    growthStage: 'Tillering',
    soilType: 'Loam',
  });
  const [irrigationResult, setIrrigationResult] = useState<any | null>(null);

  // 3. Crop Suitability
  const [suitabilityForm, setSuitabilityForm] = useState({
    nitrogen: 54,
    phosphorus: 32,
    potassium: 48,
    temperature: 28,
    humidity: 65,
    ph: 6.7,
    rainfall: 75,
  });
  const [suitabilityResult, setSuitabilityResult] = useState<any | null>(null);

  // 4. Crop Health
  const [healthForm, setHealthForm] = useState({
    soilMoisture: 35,
    temperature: 29,
    ph: 6.7,
    nitrogen: 52,
  });
  const [healthResult, setHealthResult] = useState<any | null>(null);

  useEffect(() => {
    mlService.getModels().then(setBenchmarks).catch(console.error);
    // run initial predictions
    handlePredictMoisture();
  }, []);

  const handlePredictMoisture = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsLoading(true);
    try {
      const res = await mlService.predictSoilMoisture(moistureForm);
      setMoistureResult(res);
    } catch (err) {
      alert('Failed to run soil moisture model');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePredictIrrigation = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await mlService.predictIrrigation(irrigationForm);
      setIrrigationResult(res);
    } catch (err) {
      alert('Failed to run irrigation model');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePredictSuitability = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await mlService.predictCropSuitability(suitabilityForm);
      setSuitabilityResult(res);
    } catch (err) {
      alert('Failed to run crop suitability model');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePredictHealth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await mlService.predictCropHealth(healthForm);
      setHealthResult(res);
    } catch (err) {
      alert('Failed to run crop health model');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full border border-purple-200">
            Machine Learning Inference Engine
          </span>
          <span className="text-xs text-slate-400 font-mono">Scikit-Learn Architecture • Empirical Model Weights</span>
        </div>
        <h2 className="text-xl font-black text-slate-800 tracking-tight">Machine Learning Prediction Center</h2>
        <p className="text-xs text-slate-500">
          Trained on synchronized microclimate, capacitance sensor telemetry and historical crop response datasets
        </p>
      </div>

      {/* Model Selection Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-px">
        {[
          { id: 'moisture', label: '1. Soil Moisture Forecaster', icon: Droplets },
          { id: 'irrigation', label: '2. Irrigation Classifier', icon: Activity },
          { id: 'suitability', label: '3. Crop Suitability Recommender', icon: Wheat },
          { id: 'health', label: '4. Crop Health Classifier', icon: Sparkles },
          { id: 'benchmarks', label: 'Model Evaluation Benchmarks', icon: BarChart3 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 text-xs font-bold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
                isActive
                  ? 'border-emerald-600 text-emerald-700 bg-emerald-50/50 rounded-t-xl'
                  : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* TAB 1: SOIL MOISTURE FORECASTER */}
      {activeTab === 'moisture' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
            <h3 className="text-base font-bold text-slate-800 mb-1">Soil Moisture Regression Model</h3>
            <p className="text-xs text-slate-500 mb-4">
              Predicts future root zone volumetric water content based on ambient temperature, humidity, and forecast rainfall.
            </p>

            <form onSubmit={handlePredictMoisture} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Ambient Temperature ({moistureForm.temperature}°C)
                </label>
                <input
                  type="range"
                  min="15"
                  max="45"
                  value={moistureForm.temperature}
                  onChange={(e) => setMoistureForm({ ...moistureForm, temperature: parseFloat(e.target.value) })}
                  className="w-full accent-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Relative Humidity ({moistureForm.humidity}%)
                </label>
                <input
                  type="range"
                  min="20"
                  max="95"
                  value={moistureForm.humidity}
                  onChange={(e) => setMoistureForm({ ...moistureForm, humidity: parseFloat(e.target.value) })}
                  className="w-full accent-sky-600"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Current Soil Moisture ({moistureForm.currentMoisture}%)
                </label>
                <input
                  type="range"
                  min="10"
                  max="80"
                  value={moistureForm.currentMoisture}
                  onChange={(e) => setMoistureForm({ ...moistureForm, currentMoisture: parseFloat(e.target.value) })}
                  className="w-full accent-emerald-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Expected Rain (mm)</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={moistureForm.rainfall}
                    onChange={(e) => setMoistureForm({ ...moistureForm, rainfall: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Days Ahead</label>
                  <select
                    value={moistureForm.daysAhead}
                    onChange={(e) => setMoistureForm({ ...moistureForm, daysAhead: parseInt(e.target.value, 10) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="1">1 Day Ahead</option>
                    <option value="2">2 Days Ahead</option>
                    <option value="3">3 Days Ahead</option>
                    <option value="5">5 Days Ahead</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition-colors"
              >
                {isLoading ? 'Computing Regression...' : 'Run Soil Moisture Prediction'}
              </button>
            </form>
          </div>

          {/* Result Card */}
          <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">Model Inference Result</span>
                <span className="text-xs font-mono text-slate-400">Model: Random Forest Regressor</span>
              </div>

              {moistureResult ? (
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700">
                    <span className="text-xs text-slate-400 font-semibold">Predicted Soil Moisture ({moistureForm.daysAhead}d ahead)</span>
                    <div className="flex items-baseline gap-3 mt-1">
                      <span className="text-4xl font-extrabold text-emerald-400 font-mono">
                        {moistureResult.prediction} {moistureResult.unit}
                      </span>
                      <Badge variant={moistureResult.status === 'OPTIMAL' ? 'green' : 'amber'} size="sm">
                        {moistureResult.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-400 mt-2 font-mono">
                      Estimated ET₀ Evapotranspiration: {moistureResult.evapotranspirationMmDay} mm/day
                    </p>
                  </div>

                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                      Feature Impact Breakdown
                    </h4>
                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      {(moistureResult.importantFeatures || []).map((f: any) => (
                        <div key={f.feature} className="p-2.5 rounded-xl bg-slate-800 border border-slate-700">
                          <span className="text-slate-400 text-[10px] block">{f.feature}</span>
                          <span className="font-bold text-slate-200">{f.impact}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <LoadingSpinner message="Generating prediction..." className="h-48" />
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Model R² Benchmark: <strong>0.941</strong></span>
              <span>Confidence: <strong>{((moistureResult?.confidence || 0.94) * 100).toFixed(0)}%</strong></span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: IRRIGATION CLASSIFIER */}
      {activeTab === 'irrigation' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
            <h3 className="text-base font-bold text-slate-800 mb-1">Irrigation Classifier (Gradient Boosted Trees)</h3>
            <p className="text-xs text-slate-500 mb-4">
              Determines binary irrigation necessity and computes exact supplemental water depth (mm).
            </p>

            <form onSubmit={handlePredictIrrigation} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Soil Moisture (%)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={irrigationForm.soilMoisture}
                    onChange={(e) => setIrrigationForm({ ...irrigationForm, soilMoisture: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Temperature (°C)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={irrigationForm.temperature}
                    onChange={(e) => setIrrigationForm({ ...irrigationForm, temperature: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Humidity (%)</label>
                  <input
                    type="number"
                    value={irrigationForm.humidity}
                    onChange={(e) => setIrrigationForm({ ...irrigationForm, humidity: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Forecast Rain (mm)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={irrigationForm.rainfallForecast}
                    onChange={(e) => setIrrigationForm({ ...irrigationForm, rainfallForecast: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Crop Variety</label>
                  <select
                    value={irrigationForm.cropType}
                    onChange={(e) => setIrrigationForm({ ...irrigationForm, cropType: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="Rice">Rice</option>
                    <option value="Wheat">Wheat</option>
                    <option value="Cotton">Cotton</option>
                    <option value="Maize">Maize</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Soil Type</label>
                  <select
                    value={irrigationForm.soilType}
                    onChange={(e) => setIrrigationForm({ ...irrigationForm, soilType: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="Loam">Loam</option>
                    <option value="Clay">Clay</option>
                    <option value="Black Soil">Black Soil</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition-colors"
              >
                {isLoading ? 'Running Decision Forest...' : 'Evaluate Irrigation Requirement'}
              </button>
            </form>
          </div>

          <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-sky-400">Classification Inference</span>
                <span className="text-xs font-mono text-slate-400">Accuracy: 96.3%</span>
              </div>

              {irrigationResult ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-4 rounded-2xl bg-slate-800 border border-slate-700">
                      <span className="text-xs text-slate-400">Irrigation Needed</span>
                      <p className="text-2xl font-black text-emerald-400 font-mono mt-1">
                        {irrigationResult.prediction}
                      </p>
                    </div>
                    <div className="p-4 rounded-2xl bg-slate-800 border border-slate-700">
                      <span className="text-xs text-slate-400">Priority & Depth</span>
                      <p className="text-lg font-black text-amber-400 font-mono mt-1">
                        {irrigationResult.priority} ({irrigationResult.recommendedWaterAmount})
                      </p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 text-xs text-slate-300 leading-relaxed font-mono">
                    {irrigationResult.reason}
                  </div>
                </div>
              ) : (
                <div className="h-48 flex items-center justify-center text-xs text-slate-400">
                  Submit parameters to view classification decision tree path.
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>AUC-ROC: <strong>0.985</strong></span>
              <span>Model: <strong>XGBoost / GBDT</strong></span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CROP SUITABILITY RECOMMENDER */}
      {activeTab === 'suitability' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
            <h3 className="text-base font-bold text-slate-800 mb-1">Crop Suitability Recommender</h3>
            <p className="text-xs text-slate-500 mb-4">
              K-Nearest Neighbors & Random Forest multi-crop matching based on soil chemistry and climate.
            </p>

            <form onSubmit={handlePredictSuitability} className="space-y-4 text-xs">
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Nitrogen (N)</label>
                  <input
                    type="number"
                    value={suitabilityForm.nitrogen}
                    onChange={(e) => setSuitabilityForm({ ...suitabilityForm, nitrogen: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Phosphorus (P)</label>
                  <input
                    type="number"
                    value={suitabilityForm.phosphorus}
                    onChange={(e) => setSuitabilityForm({ ...suitabilityForm, phosphorus: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Potassium (K)</label>
                  <input
                    type="number"
                    value={suitabilityForm.potassium}
                    onChange={(e) => setSuitabilityForm({ ...suitabilityForm, potassium: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Temp (°C)</label>
                  <input
                    type="number"
                    value={suitabilityForm.temperature}
                    onChange={(e) => setSuitabilityForm({ ...suitabilityForm, temperature: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Humidity (%)</label>
                  <input
                    type="number"
                    value={suitabilityForm.humidity}
                    onChange={(e) => setSuitabilityForm({ ...suitabilityForm, humidity: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Soil pH</label>
                  <input
                    type="number"
                    step="0.1"
                    value={suitabilityForm.ph}
                    onChange={(e) => setSuitabilityForm({ ...suitabilityForm, ph: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition-colors"
              >
                {isLoading ? 'Classifying Crop Affinities...' : 'Rank Suitable Crops'}
              </button>
            </form>
          </div>

          <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400">Recommended Crops</span>
                <span className="text-xs font-mono text-slate-400">KNN (k=7) + RF</span>
              </div>

              {suitabilityResult ? (
                <div className="space-y-3">
                  <div className="p-4 bg-emerald-950/60 border border-emerald-500/40 rounded-2xl">
                    <span className="text-xs text-emerald-400 font-semibold">Top Recommended Crop</span>
                    <h3 className="text-2xl font-black text-white mt-0.5">{suitabilityResult.recommendedCrop}</h3>
                    <p className="text-xs text-slate-300 mt-1">
                      Highest biological compatibility with current NPK and pH levels.
                    </p>
                  </div>

                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {(suitabilityResult.allRankings || []).map((c: any) => (
                      <div key={c.name} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs">
                        <span className="font-bold text-slate-200">{c.name}</span>
                        <div className="flex items-center gap-3">
                          <div className="w-24 bg-slate-700 h-1.5 rounded-full overflow-hidden">
                            <div className="bg-emerald-400 h-full rounded-full" style={{ width: `${c.score}%` }} />
                          </div>
                          <span className="font-mono text-emerald-400 font-bold">{c.score}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="h-48 flex items-center justify-center text-xs text-slate-400">
                  Select parameters to compute multi-crop agronomic suitability.
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Accuracy: <strong>94.8%</strong></span>
              <span>Classes: <strong>8 Varieties</strong></span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: CROP HEALTH CLASSIFIER */}
      {activeTab === 'health' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
            <h3 className="text-base font-bold text-slate-800 mb-1">Crop Health & Stress Classifier</h3>
            <p className="text-xs text-slate-500 mb-4">
              Multi-class Random Forest predicting physiological stress before visible foliage damage.
            </p>

            <form onSubmit={handlePredictHealth} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Soil Moisture (%)</label>
                  <input
                    type="number"
                    value={healthForm.soilMoisture}
                    onChange={(e) => setHealthForm({ ...healthForm, soilMoisture: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Temperature (°C)</label>
                  <input
                    type="number"
                    value={healthForm.temperature}
                    onChange={(e) => setHealthForm({ ...healthForm, temperature: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Soil pH</label>
                  <input
                    type="number"
                    step="0.1"
                    value={healthForm.ph}
                    onChange={(e) => setHealthForm({ ...healthForm, ph: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Nitrogen (mg/kg)</label>
                  <input
                    type="number"
                    value={healthForm.nitrogen}
                    onChange={(e) => setHealthForm({ ...healthForm, nitrogen: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition-colors"
              >
                {isLoading ? 'Assessing Stress Levels...' : 'Classify Crop Health'}
              </button>
            </form>
          </div>

          <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-rose-400">Crop Health Diagnosis</span>
                <span className="text-xs font-mono text-slate-400">Accuracy: 93.2%</span>
              </div>

              {healthResult ? (
                <div className="space-y-4">
                  <div className="p-4 bg-slate-800 rounded-2xl border border-slate-700">
                    <span className="text-xs text-slate-400">Identified Health Status</span>
                    <h3 className="text-xl font-black text-emerald-400 mt-1">{healthResult.healthStatus}</h3>
                    <div className="flex items-center gap-3 mt-2">
                      <span className="text-xs font-mono text-slate-300">Risk Level: <strong>{healthResult.riskLevel}</strong></span>
                      <span className="text-xs font-mono text-emerald-400">Health Index: <strong>{healthResult.healthScore}/100</strong></span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-48 flex items-center justify-center text-xs text-slate-400">
                  Input soil and microclimate measurements to identify health status.
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Precision: <strong>92.5%</strong></span>
              <span>F1 Score: <strong>93.1%</strong></span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: MODEL EVALUATION BENCHMARKS (Academic & Research Focus) */}
      {activeTab === 'benchmarks' && benchmarks && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
            <h3 className="text-base font-bold text-slate-800 mb-1">Empirical Model Performance Verification</h3>
            <p className="text-xs text-slate-500 mb-6">
              Evaluation metrics rigorously computed on 4,320 historical field telemetry instances (80/20 train/test split).
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Regression Metrics */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Soil Moisture Regression
                  </h4>
                  <Badge variant="green" size="sm">Regression</Badge>
                </div>
                <p className="text-xs text-slate-500 font-mono">Algorithm: {benchmarks.soilMoistureModel.algorithm}</p>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">MAE (Mean Absolute Error)</span>
                    <span className="text-base font-black text-slate-800">{benchmarks.soilMoistureModel.mae}%</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">MSE (Mean Squared Error)</span>
                    <span className="text-base font-black text-slate-800">{benchmarks.soilMoistureModel.mse}</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">RMSE (Root Mean Sq Error)</span>
                    <span className="text-base font-black text-slate-800">{benchmarks.soilMoistureModel.rmse}%</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-emerald-200 bg-emerald-50/50">
                    <span className="text-emerald-700 block text-[10px] font-bold">R² Determination Score</span>
                    <span className="text-base font-black text-emerald-800">{benchmarks.soilMoistureModel.r2Score}</span>
                  </div>
                </div>
              </div>

              {/* Classification Metrics */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Irrigation Classification Model
                  </h4>
                  <Badge variant="blue" size="sm">Classification</Badge>
                </div>
                <p className="text-xs text-slate-500 font-mono">Algorithm: {benchmarks.irrigationModel.algorithm}</p>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">Accuracy</span>
                    <span className="text-base font-black text-slate-800">{(benchmarks.irrigationModel.accuracy * 100).toFixed(1)}%</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">Precision</span>
                    <span className="text-base font-black text-slate-800">{(benchmarks.irrigationModel.precision * 100).toFixed(1)}%</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">Recall</span>
                    <span className="text-base font-black text-slate-800">{(benchmarks.irrigationModel.recall * 100).toFixed(1)}%</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-sky-200 bg-sky-50/50">
                    <span className="text-sky-700 block text-[10px] font-bold">F1-Score</span>
                    <span className="text-base font-black text-sky-800">{(benchmarks.irrigationModel.f1Score * 100).toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
