import React, { useState, useEffect } from 'react';
import {
  Database,
  Upload,
  Download,
  Sparkles,
  FileCheck,
  AlertCircle,
  CheckCircle2,
  Trash2,
  Table,
  Filter,
  RefreshCw,
  Search,
} from 'lucide-react';
import { datasetService } from '../services/api';
import { Dataset } from '../types';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const DatasetManagementPage: React.FC = () => {
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [activeDataset, setActiveDataset] = useState<Dataset | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isCleaning, setIsCleaning] = useState(false);
  const [cleanMessage, setCleanMessage] = useState<string | null>(null);

  // Upload modal state
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [datasetName, setDatasetName] = useState('Paddy_Soil_Weather_Microclimate_2026.csv');
  const [sampleRowCount, setSampleRowCount] = useState('250');

  const loadDatasets = async () => {
    try {
      setIsLoading(true);
      const list = await datasetService.getAll();
      setDatasets(list);
      if (list.length > 0 && !activeDataset) {
        const fullDs = await datasetService.getById(list[0].id);
        setActiveDataset(fullDs);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDatasets();
  }, []);

  const handleSelectDataset = async (id: string) => {
    try {
      const fullDs = await datasetService.getById(id);
      setActiveDataset(fullDs);
      setCleanMessage(null);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCleanDataset = async () => {
    if (!activeDataset) return;
    setIsCleaning(true);
    setCleanMessage(null);
    try {
      const res = await datasetService.clean(activeDataset.id);
      setActiveDataset(res.dataset);
      setCleanMessage(res.message);
      loadDatasets();
    } catch (err) {
      alert('Failed to clean dataset.');
    } finally {
      setIsCleaning(false);
    }
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const newDs = await datasetService.upload({
        name: datasetName,
        rows: Array.from({ length: parseInt(sampleRowCount, 10) || 120 }),
      });
      setShowUploadModal(false);
      await loadDatasets();
      setActiveDataset(newDs);
    } catch (err) {
      alert('Upload failed.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full border border-purple-200">
              Research Data Repository
            </span>
            <span className="text-xs text-slate-400 font-mono">13 Agricultural Features • CSV Parser & Preprocessor</span>
          </div>
          <h2 className="text-xl font-black text-slate-800 tracking-tight">Dataset Management & Preprocessing</h2>
          <p className="text-xs text-slate-500">
            Upload, preview, validate, clean, and export synchronized in-situ soil and weather tabular datasets
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors shrink-0"
        >
          <Upload className="w-4 h-4" /> Upload Dataset (CSV)
        </button>
      </div>

      {/* Dataset Selection Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {datasets.map((ds) => (
          <button
            key={ds.id}
            onClick={() => handleSelectDataset(ds.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-2 whitespace-nowrap ${
              activeDataset?.id === ds.id
                ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span className="truncate max-w-[200px]">{ds.name}</span>
            <Badge variant={ds.status === 'CLEANED' ? 'green' : 'amber'} size="sm">
              {ds.status}
            </Badge>
          </button>
        ))}
      </div>

      {activeDataset && (
        <div className="space-y-6">
          {/* Dataset Diagnostic Stats Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Total Records
              </span>
              <p className="text-2xl font-black text-slate-800 font-mono">{activeDataset.recordCount}</p>
              <p className="text-[10px] text-slate-500 mt-0.5">Rows collected</p>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Missing Values
              </span>
              <p className="text-2xl font-black text-amber-600 font-mono">{activeDataset.missingValues}</p>
              <p className="text-[10px] text-slate-500 mt-0.5">Null or blank cells</p>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Duplicate Rows
              </span>
              <p className="text-2xl font-black text-slate-700 font-mono">{activeDataset.duplicateCount}</p>
              <p className="text-[10px] text-slate-500 mt-0.5">Identical timestamps</p>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Outliers Detected
              </span>
              <p className="text-2xl font-black text-rose-600 font-mono">{activeDataset.outlierCount}</p>
              <p className="text-[10px] text-slate-500 mt-0.5">&gt; 3-sigma noise spikes</p>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Pipeline Status
              </span>
              <div className="mt-1">
                <Badge variant={activeDataset.status === 'CLEANED' ? 'green' : 'amber'} size="md" dot>
                  {activeDataset.status === 'CLEANED' ? 'Ready for ML' : 'Raw Input'}
                </Badge>
              </div>
              <p className="text-[10px] text-slate-500 mt-1">Uploaded {activeDataset.uploadedAt.slice(0, 10)}</p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="text-xs font-bold text-slate-800">{activeDataset.name}</h4>
              <p className="text-[11px] text-slate-400">
                Uploaded by {activeDataset.uploadedBy} • 13 schema fields verified
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCleanDataset}
                disabled={isCleaning || activeDataset.status === 'CLEANED'}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {isCleaning ? 'Preprocessing...' : activeDataset.status === 'CLEANED' ? 'Cleaned & Standardized' : 'Execute Cleaning Pipeline'}
              </button>

              <a
                href={datasetService.getDownloadUrl(activeDataset.id)}
                download={activeDataset.name}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                Download CSV
              </a>
            </div>
          </div>

          {/* Pipeline Clean Success Message */}
          {cleanMessage && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900 flex items-start gap-2.5 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Preprocessing Execution Complete</p>
                <p className="mt-0.5">{cleanMessage}</p>
              </div>
            </div>
          )}

          {/* DATASET TABLE PREVIEW (13 expected columns) */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800">
                Dataset Table Preview (Showing First 20 Rows)
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                13 Features: timestamp, soil_moisture, soil_temp, soil_ph, N, P, K, temp, hum, rain, wind, crop
              </span>
            </div>

            <div className="overflow-x-auto max-h-96">
              <table className="w-full text-left text-[11px] font-mono whitespace-nowrap">
                <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100 sticky top-0">
                  <tr>
                    <th className="px-3 py-2.5">timestamp</th>
                    <th className="px-3 py-2.5">farm_id</th>
                    <th className="px-3 py-2.5 text-emerald-700">soil_moisture (%)</th>
                    <th className="px-3 py-2.5">soil_temp (°C)</th>
                    <th className="px-3 py-2.5">soil_ph</th>
                    <th className="px-3 py-2.5">nitrogen</th>
                    <th className="px-3 py-2.5">phosphorus</th>
                    <th className="px-3 py-2.5">potassium</th>
                    <th className="px-3 py-2.5 text-amber-700">temp (°C)</th>
                    <th className="px-3 py-2.5 text-sky-700">humidity (%)</th>
                    <th className="px-3 py-2.5 text-sky-700">rainfall (mm)</th>
                    <th className="px-3 py-2.5">wind_speed</th>
                    <th className="px-3 py-2.5">crop_type</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {(activeDataset.dataPreview || []).map((r: any, idx: number) => (
                    <tr key={idx} className="hover:bg-slate-50/80">
                      <td className="px-3 py-2 text-slate-400">{r.timestamp?.slice(0, 16).replace('T', ' ')}</td>
                      <td className="px-3 py-2 font-bold text-slate-800">{r.farm_id}</td>
                      <td className="px-3 py-2 text-emerald-700 font-bold">{r.soil_moisture}</td>
                      <td className="px-3 py-2">{r.soil_temperature}</td>
                      <td className="px-3 py-2">{r.soil_ph}</td>
                      <td className="px-3 py-2">{r.nitrogen}</td>
                      <td className="px-3 py-2">{r.phosphorus}</td>
                      <td className="px-3 py-2">{r.potassium}</td>
                      <td className="px-3 py-2 text-amber-700">{r.temperature}</td>
                      <td className="px-3 py-2 text-sky-700">{r.humidity}</td>
                      <td className="px-3 py-2 text-sky-700 font-bold">{r.rainfall}</td>
                      <td className="px-3 py-2">{r.wind_speed}</td>
                      <td className="px-3 py-2 font-sans font-bold text-emerald-800">{r.crop_type}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* UPLOAD DATASET MODAL */}
      <Modal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        title="Upload Agricultural Telemetry Dataset"
        subtitle="Ingest multi-variable sensor recordings in CSV format for ML modeling."
      >
        <form onSubmit={handleUploadSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Dataset Filename</label>
            <input
              type="text"
              required
              value={datasetName}
              onChange={(e) => setDatasetName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Simulated Sample Ingestion Size</label>
            <select
              value={sampleRowCount}
              onChange={(e) => setSampleRowCount(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold"
            >
              <option value="120">120 Records (5-day probe sample)</option>
              <option value="250">250 Records (10-day probe sample)</option>
              <option value="720">720 Records (30-day month sample)</option>
              <option value="4320">4,320 Records (Full Multi-Month Study)</option>
            </select>
          </div>

          <div className="p-4 border-2 border-dashed border-slate-300 rounded-2xl text-center bg-slate-50/50">
            <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="font-bold text-slate-700">Drop CSV file here, or click to load sample schema</p>
            <p className="text-[10px] text-slate-400 mt-1">
              Supports columns: timestamp, farm_id, soil_moisture, soil_temp, soil_ph, N, P, K, temp, humidity, rainfall, wind_speed, crop_type
            </p>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setShowUploadModal(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl"
            >
              Upload & Ingest Table
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
