import React from 'react';
import {
  AlertTriangle,
  Bug,
  Thermometer,
  Droplets,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  HelpCircle,
  MapPin,
  TrendingUp,
} from 'lucide-react';
import { Badge } from '../components/common/Badge';
import { useAuth } from '../context/AuthContext';

export const DiseaseRiskPage: React.FC = () => {
  const { selectedFarmId } = useAuth();

  const riskFactors = [
    {
      id: 'rf-1',
      title: 'Fungal Blast (Magnaporthe oryzae)',
      targetCrop: 'Rice (Paddy)',
      riskLevel: 'MEDIUM',
      indexScore: 58,
      drivingParameters: 'High humidity (>75%) coupled with overnight dew and moderate temperatures (24°C–28°C).',
      symptoms: 'Spindle-shaped elliptical lesions with gray centers on leaf blades and neck rot.',
      preventativeAction: 'Avoid excessive nitrogen top-dressing; maintain intermittent irrigation drying cycles; prophylactic spray of Tricyclazole if humidity persists.',
    },
    {
      id: 'rf-2',
      title: 'Canopy Heat Stress Index',
      targetCrop: 'All Monitored Crops',
      riskLevel: 'LOW',
      indexScore: 32,
      drivingParameters: 'Canopy temperature steady at 29.4°C with healthy transpiration cooling.',
      symptoms: 'Pollen sterility during anthesis, stomatal closure, leaf curling.',
      preventativeAction: 'Schedule early morning misting/sprinklers if afternoon temperature peaks exceed 36°C.',
    },
    {
      id: 'rf-3',
      title: 'Root Zone Moisture Stress (Wilting)',
      targetCrop: 'Rice & Cotton',
      riskLevel: 'HIGH',
      indexScore: 74,
      drivingParameters: 'Volumetric soil moisture dropped to 26.8% (below optimal threshold of 30%).',
      symptoms: 'Temporary midday wilting, reduced tiller count, accelerated leaf senescence.',
      preventativeAction: 'Immediate supplemental irrigation of 25 mm recommended within 12 hours.',
    },
    {
      id: 'rf-4',
      title: 'Stem Borer & Leaf Folder Risk',
      targetCrop: 'Rice & Maize',
      riskLevel: 'LOW',
      indexScore: 28,
      drivingParameters: 'Moderate ambient wind and low nocturnal flight activity detected by light traps.',
      symptoms: 'Dead hearts in vegetative stage and white ears at reproductive phase.',
      preventativeAction: 'Deploy pheromone traps at 5 traps/acre for periodic monitoring; release Trichogramma biocontrol agents if moth counts escalate.',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-bold uppercase tracking-wider text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
            Plant Pathology & Biotic Risk
          </span>
          <span className="text-xs text-slate-400 font-mono">Microclimate Epidemiology Models</span>
        </div>
        <h2 className="text-xl font-black text-slate-800 tracking-tight">Disease & Pest Risk Analysis</h2>
        <p className="text-xs text-slate-500">
          Combines ambient temperature, vapor pressure deficit, relative humidity, and vegetative density to forecast pathogen outbreaks
        </p>
      </div>

      {/* Summary Score Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Cumulative Pathogen Risk</span>
            <Badge variant="amber" size="sm" dot>Moderate (48/100)</Badge>
          </div>
          <p className="text-2xl font-black text-slate-800 font-mono mt-3">Moderate</p>
          <p className="text-xs text-slate-400 mt-1">Weather conditions favorable for fungal incubation</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Moisture Stress Level</span>
            <Badge variant="red" size="sm" dot>High (74/100)</Badge>
          </div>
          <p className="text-2xl font-black text-rose-600 font-mono mt-3">Elevated</p>
          <p className="text-xs text-slate-400 mt-1">Active deficit in Plot 2 root zone</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Canopy Thermal Buffer</span>
            <Badge variant="green" size="sm" dot>Optimal (32/100)</Badge>
          </div>
          <p className="text-2xl font-black text-emerald-600 font-mono mt-3">Safe</p>
          <p className="text-xs text-slate-400 mt-1">Normal evaporative cooling active</p>
        </div>
      </div>

      {/* Detailed Risk Items */}
      <div className="space-y-4">
        {riskFactors.map((rf) => (
          <div
            key={rf.id}
            className="p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div
                  className={`p-2 rounded-xl ${
                    rf.riskLevel === 'HIGH'
                      ? 'bg-rose-100 text-rose-700'
                      : rf.riskLevel === 'MEDIUM'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-emerald-100 text-emerald-700'
                  }`}
                >
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800">{rf.title}</h3>
                  <p className="text-[11px] text-slate-400">Target Crop: {rf.targetCrop}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs font-mono font-bold text-slate-600">Risk Score: {rf.indexScore}/100</span>
                <Badge
                  variant={rf.riskLevel === 'HIGH' ? 'red' : rf.riskLevel === 'MEDIUM' ? 'amber' : 'green'}
                  size="sm"
                  dot
                >
                  {rf.riskLevel} RISK
                </Badge>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-2 border-t border-slate-100">
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Environmental Drivers
                </span>
                <p className="text-slate-700">{rf.drivingParameters}</p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Phenotypic Symptoms
                </span>
                <p className="text-slate-700">{rf.symptoms}</p>
              </div>

              <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-xl">
                <span className="block text-[10px] font-bold uppercase tracking-wider text-emerald-700 mb-1">
                  Recommended Agronomic Mitigation
                </span>
                <p className="text-emerald-900 font-medium">{rf.preventativeAction}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
