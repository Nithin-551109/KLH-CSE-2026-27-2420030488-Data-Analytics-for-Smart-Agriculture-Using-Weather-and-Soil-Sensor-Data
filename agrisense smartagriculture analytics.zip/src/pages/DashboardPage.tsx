import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Radio,
  Droplets,
  Thermometer,
  CloudRain,
  Wind,
  HeartPulse,
  Activity,
  Layers,
  Calendar,
  AlertTriangle,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  Sparkles,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import { analyticsService, farmService } from '../services/api';
import { DashboardAnalytics, Farm } from '../types';
import { StatCard } from '../components/common/StatCard';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { ErrorMessage } from '../components/common/ErrorMessage';
import { Badge } from '../components/common/Badge';

interface DashboardPageProps {
  onNavigate: (page: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { selectedFarmId, setSelectedFarmId, selectedRange, setSelectedRange, liveTick } = useAuth();
  const [data, setData] = useState<DashboardAnalytics | null>(null);
  const [farms, setFarms] = useState<Farm[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    farmService.getAll().then(setFarms).catch(console.error);
  }, []);

  const loadData = async () => {
    try {
      setError(null);
      const res = await analyticsService.getDashboard(selectedFarmId, selectedRange);
      setData(res);
    } catch (err) {
      console.error(err);
      setError('Unable to fetch live farm telemetry. Please verify server connectivity.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedFarmId, selectedRange, liveTick]);

  if (isLoading && !data) {
    return <LoadingSpinner message="Querying PostgreSQL sensor records & ML analytics..." />;
  }

  if (error && !data) {
    return <ErrorMessage message={error} onRetry={loadData} />;
  }

  const kpis = data?.kpis;
  const activeFarm = farms.find((f) => f.id === selectedFarmId) || farms[0];

  return (
    <div className="space-y-6">
      {/* Top Banner / Filter Bar */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              Active Monitoring Hub
            </span>
            <span className="text-xs text-slate-400 font-medium">Real-time Ingest: Active</span>
          </div>
          <h2 className="text-xl font-black text-slate-800 tracking-tight">
            {activeFarm?.name || 'Smart Agriculture Field Unit'}
          </h2>
          <p className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
            <MapPin className="w-3.5 h-3.5 text-slate-400" />
            {activeFarm?.location} • Crop: <strong>{activeFarm?.crop}</strong> • Soil: {activeFarm?.soilType}
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Farm selector */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs">
            <span className="text-slate-400 font-medium">Farm:</span>
            <select
              value={selectedFarmId}
              onChange={(e) => setSelectedFarmId(e.target.value)}
              className="bg-transparent font-bold text-slate-800 focus:outline-hidden cursor-pointer"
            >
              {farms.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>

          {/* Date Range Selector */}
          <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-xl p-1 text-xs">
            {['Today', '7 Days', '30 Days', '3 Months'].map((r) => (
              <button
                key={r}
                onClick={() => setSelectedRange(r)}
                className={`px-2.5 py-1 rounded-lg text-xs transition-all ${
                  selectedRange === r
                    ? 'bg-emerald-600 text-white font-bold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 font-medium'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 8 TOP STAT CARDS (All populated from live backend API) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {/* Card 1: Total Farms */}
        <StatCard
          title="Total Farms"
          value={kpis?.totalFarms ?? 4}
          unit="fields"
          icon={MapPin}
          accentColor="emerald"
          subtitle="Managed across regions"
          onClick={() => onNavigate('farms')}
        />

        {/* Card 2: Active Sensors */}
        <StatCard
          title="Active Sensors"
          value={`${kpis?.activeSensors ?? 36} / ${kpis?.totalSensors ?? 36}`}
          unit="online"
          icon={Radio}
          accentColor="sky"
          subtitle="100% telemetry online"
          onClick={() => onNavigate('sensors')}
          statusBadge={<Badge variant="green" size="sm" dot>Active</Badge>}
        />

        {/* Card 3: Avg Soil Moisture */}
        <StatCard
          title="Soil Moisture"
          value={kpis?.avgSoilMoisture ?? 36.8}
          unit="%"
          icon={Droplets}
          accentColor={
            (kpis?.avgSoilMoisture ?? 35) < 30 ? 'amber' : 'emerald'
          }
          trend={{
            value: (kpis?.avgSoilMoisture ?? 35) < 30 ? 'Below optimal 30%' : 'Optimal range',
            isPositive: (kpis?.avgSoilMoisture ?? 35) >= 30,
          }}
          onClick={() => onNavigate('soil')}
        />

        {/* Card 4: Avg Temperature */}
        <StatCard
          title="Avg Temperature"
          value={kpis?.avgTemperature ?? 29.4}
          unit="°C"
          icon={Thermometer}
          accentColor="amber"
          subtitle="Canopy & ambient sensor"
          onClick={() => onNavigate('weather')}
        />

        {/* Card 5: Avg Humidity */}
        <StatCard
          title="Avg Humidity"
          value={kpis?.avgHumidity ?? 65.2}
          unit="%"
          icon={Wind}
          accentColor="sky"
          subtitle="Relative vapor saturation"
          onClick={() => onNavigate('weather')}
        />

        {/* Card 6: Rainfall */}
        <StatCard
          title="Precipitation"
          value={kpis?.rainfall ?? 2.1}
          unit="mm"
          icon={CloudRain}
          accentColor="sky"
          subtitle="Past 24 hours accumulation"
          onClick={() => onNavigate('weather')}
        />

        {/* Card 7: Crop Health */}
        <StatCard
          title="Crop Health"
          value={kpis?.cropHealth ?? 86}
          unit="/ 100"
          icon={HeartPulse}
          accentColor={
            (kpis?.cropHealth ?? 80) >= 80 ? 'emerald' : 'amber'
          }
          subtitle={`Status: ${kpis?.cropHealthStatus || 'Good'}`}
          onClick={() => onNavigate('crops')}
        />

        {/* Card 8: Water Requirement */}
        <StatCard
          title="Water Requirement"
          value={kpis?.waterRequirement ?? 6.5}
          unit="mm/day"
          icon={Droplets}
          accentColor={
            kpis?.irrigationStatus === 'REQUIRED' ? 'rose' : 'emerald'
          }
          subtitle={`Advisory: ${kpis?.irrigationStatus || 'SUFFICIENT'}`}
          onClick={() => onNavigate('irrigation')}
          statusBadge={
            <Badge
              variant={kpis?.irrigationStatus === 'REQUIRED' ? 'amber' : 'green'}
              size="sm"
            >
              {kpis?.irrigationStatus}
            </Badge>
          }
        />
      </div>

      {/* QUICK IRRIGATION ADVISORY BANNER */}
      {data?.activeRecommendation && (
        <div className="bg-gradient-to-r from-emerald-900 to-teal-950 rounded-2xl p-5 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-400">
              <Droplets className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                  Automated Irrigation Recommendation
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 border border-emerald-500/40">
                  Priority: {data.activeRecommendation.priority}
                </span>
              </div>
              <h3 className="text-base font-extrabold mt-0.5">{data.activeRecommendation.title}</h3>
              <p className="text-xs text-slate-300 mt-1 max-w-3xl leading-relaxed">
                {data.activeRecommendation.reason}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="text-right hidden sm:block">
              <span className="block text-[10px] text-slate-400 uppercase font-semibold">Recommended Water</span>
              <span className="text-lg font-black text-emerald-400 font-mono">
                {data.activeRecommendation.recommendedWaterAmount}
              </span>
            </div>
            <button
              onClick={() => onNavigate('irrigation')}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black rounded-xl transition-all shadow-xs flex items-center gap-1.5"
            >
              Examine Advisory <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* 8 INTERACTIVE CHARTS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Soil Moisture Trend */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">1. Soil Moisture Dynamic Trend</h3>
              <p className="text-xs text-slate-400">Root-zone volumetric water content (%) over time</p>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-200">
              Optimal: 30% - 70%
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data?.trends || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis domain={[15, 80]} tick={{ fontSize: 10 }} stroke="#94a3b8" unit="%" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Line
                  type="monotone"
                  dataKey="soilMoisture"
                  name="Soil Moisture"
                  stroke="#10b981"
                  strokeWidth={2.5}
                  dot={{ r: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Temperature Trend */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">2. Ambient & Canopy Temperature</h3>
              <p className="text-xs text-slate-400">Diurnal heat cycle (°C)</p>
            </div>
            <span className="text-xs font-mono font-bold text-amber-600 bg-amber-50 px-2 py-1 rounded-md border border-amber-200">
              Threshold: &lt; 35°C
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data?.trends || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis domain={[18, 42]} tick={{ fontSize: 10 }} stroke="#94a3b8" unit="°C" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Line
                  type="monotone"
                  dataKey="temperature"
                  name="Temperature"
                  stroke="#f59e0b"
                  strokeWidth={2.5}
                  dot={{ r: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Humidity Trend */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">3. Relative Atmospheric Humidity</h3>
              <p className="text-xs text-slate-400">Atmospheric vapor percentage (%)</p>
            </div>
            <span className="text-xs font-mono font-bold text-sky-600 bg-sky-50 px-2 py-1 rounded-md border border-sky-200">
              Normal: 40% - 80%
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data?.trends || []}>
                <defs>
                  <linearGradient id="humidityGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis domain={[30, 95]} tick={{ fontSize: 10 }} stroke="#94a3b8" unit="%" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Area
                  type="monotone"
                  dataKey="humidity"
                  name="Relative Humidity"
                  stroke="#0284c7"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#humidityGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Rainfall Trend */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">4. Precipitation Events</h3>
              <p className="text-xs text-slate-400">Microclimate gauge accumulation (mm)</p>
            </div>
            <span className="text-xs font-mono text-slate-500">Tipping Bucket Gauge</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data?.trends || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis tick={{ fontSize: 10 }} stroke="#94a3b8" unit=" mm" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="rainfall" name="Rainfall" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 5: Soil pH Trend */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">5. Soil Acidity / Alkalinity (pH)</h3>
              <p className="text-xs text-slate-400">Electrochemical ISFET probe sensor readings</p>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-200">
              Optimal: 6.0 - 7.5
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data?.trends || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis domain={[5.5, 8.5]} tick={{ fontSize: 10 }} stroke="#94a3b8" unit=" pH" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Line
                  type="monotone"
                  dataKey="ph"
                  name="Soil pH"
                  stroke="#8b5cf6"
                  strokeWidth={2.5}
                  dot={{ r: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 6: Soil NPK Levels */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">6. Macronutrients: Nitrogen, Phosphorus, Potassium</h3>
              <p className="text-xs text-slate-400">Current sensor readings vs Agronomic Target (mg/kg)</p>
            </div>
            <span className="text-xs font-mono text-emerald-600 font-bold">Soil Chemistry</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data?.npk || []} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis type="number" unit=" mg/kg" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} stroke="#64748b" width={110} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Bar dataKey="current" name="Measured Value" fill="#10b981" radius={[0, 4, 4, 0]} />
                <Bar dataKey="target" name="Agronomic Target" fill="#cbd5e1" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 7: Weather vs Soil Moisture Correlation */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">7. Environmental Coupling: Weather vs Moisture</h3>
              <p className="text-xs text-slate-400">Direct relationship: Temperature vs Soil Moisture depletion</p>
            </div>
            <button
              onClick={() => onNavigate('research-analytics')}
              className="text-xs text-emerald-600 font-bold hover:underline"
            >
              View Matrix →
            </button>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data?.trends || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis yAxisId="left" domain={[15, 75]} tick={{ fontSize: 10 }} stroke="#10b981" unit="%" />
                <YAxis yAxisId="right" orientation="right" domain={[18, 42]} tick={{ fontSize: 10 }} stroke="#f59e0b" unit="°C" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line yAxisId="left" type="monotone" dataKey="soilMoisture" name="Soil Moisture (%)" stroke="#10b981" strokeWidth={2.5} />
                <Line yAxisId="right" type="monotone" dataKey="temperature" name="Ambient Temp (°C)" stroke="#f59e0b" strokeWidth={2} strokeDasharray="4 4" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 8: Crop Portfolio & Health Distribution */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">8. Monitored Crop Acreage & Health</h3>
              <p className="text-xs text-slate-400">Regional crop distribution across test plots</p>
            </div>
            <span className="text-xs font-bold text-slate-600">Total: 115.7 Acres</span>
          </div>
          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data?.cropDistribution || []}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${((percent || 0) * 100).toFixed(0)}%`}
                >
                  {(data?.cropDistribution || []).map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* QUICK FIELD ALERTS TABLE */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-800">Active Anomaly & Threshold Alerts</h3>
            <p className="text-xs text-slate-400">Triggered by automated backend agronomic rule-engine</p>
          </div>
          <button
            onClick={() => onNavigate('alerts')}
            className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
          >
            Manage All Alerts <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
              <tr>
                <th className="px-4 py-3">Alert Type</th>
                <th className="px-4 py-3">Farm</th>
                <th className="px-4 py-3">Severity</th>
                <th className="px-4 py-3">Description</th>
                <th className="px-4 py-3">Time</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(data?.recentAlerts || []).map((a) => (
                <tr key={a.id} className="hover:bg-slate-50/70">
                  <td className="px-4 py-3 font-bold text-slate-800">{a.type}</td>
                  <td className="px-4 py-3 text-slate-600">{a.farmName}</td>
                  <td className="px-4 py-3">
                    <Badge variant={a.severity === 'CRITICAL' ? 'red' : a.severity === 'WARNING' ? 'amber' : 'blue'} size="sm">
                      {a.severity}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-slate-600 max-w-md truncate">{a.message}</td>
                  <td className="px-4 py-3 text-slate-400 font-mono">
                    {new Date(a.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`font-semibold ${a.status === 'ACTIVE' ? 'text-rose-600' : 'text-emerald-600'}`}>
                      {a.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
