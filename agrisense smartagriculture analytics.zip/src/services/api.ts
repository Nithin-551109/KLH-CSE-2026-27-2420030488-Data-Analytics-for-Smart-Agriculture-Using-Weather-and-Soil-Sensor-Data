import axios from 'axios';
import {
  User,
  Farm,
  Sensor,
  SensorReading,
  WeatherData,
  SoilData,
  Alert,
  Recommendation,
  DashboardAnalytics,
  CorrelationData,
  Dataset,
  ThresholdSettings,
} from '../types';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Attach JWT token to requests if available
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('agrisense_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Auth Services
export const authService = {
  login: async (credentials: { email: string; password: string }) => {
    const res = await api.post<{ token: string; user: User }>('/auth/login', credentials);
    return res.data;
  },
  register: async (data: { name: string; email: string; password: string; role?: string; farmId?: string }) => {
    const res = await api.post<{ token: string; user: User }>('/auth/register', data);
    return res.data;
  },
  getCurrentUser: async () => {
    const res = await api.get<User>('/auth/me');
    return res.data;
  },
};

// Farm Services
export const farmService = {
  getAll: async () => {
    const res = await api.get<Farm[]>('/farms');
    return res.data;
  },
  getById: async (id: string) => {
    const res = await api.get<Farm>(`/farms/${id}`);
    return res.data;
  },
  create: async (data: Partial<Farm>) => {
    const res = await api.post<Farm>('/farms', data);
    return res.data;
  },
  update: async (id: string, data: Partial<Farm>) => {
    const res = await api.put<Farm>(`/farms/${id}`, data);
    return res.data;
  },
  delete: async (id: string) => {
    const res = await api.delete(`/farms/${id}`);
    return res.data;
  },
};

// Sensor Services
export const sensorService = {
  getAll: async (params?: { farmId?: string; type?: string }) => {
    const res = await api.get<Sensor[]>('/sensors', { params });
    return res.data;
  },
  getById: async (id: string) => {
    const res = await api.get<Sensor>(`/sensors/${id}`);
    return res.data;
  },
  create: async (data: Partial<Sensor>) => {
    const res = await api.post<Sensor>('/sensors', data);
    return res.data;
  },
  update: async (id: string, data: Partial<Sensor>) => {
    const res = await api.put<Sensor>(`/sensors/${id}`, data);
    return res.data;
  },
  delete: async (id: string) => {
    const res = await api.delete(`/sensors/${id}`);
    return res.data;
  },
  getReadings: async (sensorId: string, limit = 100) => {
    const res = await api.get<SensorReading[]>(`/sensors/${sensorId}/readings`, { params: { limit } });
    return res.data;
  },
  addReading: async (sensorId: string, value: number) => {
    const res = await api.post<SensorReading>(`/sensors/${sensorId}/readings`, { value });
    return res.data;
  },
};

// Weather Services
export const weatherService = {
  getWeather: async (farmId?: string) => {
    const res = await api.get<WeatherData>('/weather', { params: { farmId } });
    return res.data;
  },
};

// Soil Services
export const soilService = {
  getSoilData: async (farmId: string) => {
    const res = await api.get<SoilData>(`/soil/${farmId}`);
    return res.data;
  },
  getSoilAnalytics: async (farmId: string) => {
    const res = await api.get<{
      moistureTrend: Array<{ time: string; value: number }>;
      phTrend: Array<{ time: string; value: number }>;
      distribution: Array<{ name: string; count: number }>;
    }>(`/soil/${farmId}/analytics`);
    return res.data;
  },
};

// Analytics Services
export const analyticsService = {
  getDashboard: async (farmId?: string, range = '7 Days') => {
    const res = await api.get<DashboardAnalytics>('/analytics/dashboard', { params: { farmId, range } });
    return res.data;
  },
  getCorrelation: async (datasetId?: string) => {
    const res = await api.get<CorrelationData>('/analytics/correlation', { params: { datasetId } });
    return res.data;
  },
  getStatistics: async () => {
    const res = await api.get<{
      sampleCount: number;
      parameters: Array<{
        name: string;
        mean: number;
        median: number;
        min: number;
        max: number;
        stdDev: number;
        skewness: number;
      }>;
    }>('/analytics/statistics');
    return res.data;
  },
};

// ML Services
export const mlService = {
  getModels: async () => {
    const res = await api.get<any>('/ml/models');
    return res.data;
  },
  predictSoilMoisture: async (data: {
    temperature: number;
    humidity: number;
    rainfall: number;
    currentMoisture: number;
    daysAhead: number;
  }) => {
    const res = await api.post<{
      prediction: number;
      unit: string;
      confidence: number;
      evapotranspirationMmDay: number;
      status: string;
      importantFeatures: Array<{ feature: string; impact: string }>;
      timestamp: string;
    }>('/ml/predict/soil-moisture', data);
    return res.data;
  },
  predictIrrigation: async (data: {
    soilMoisture: number;
    temperature: number;
    humidity: number;
    rainfallForecast: number;
    cropType: string;
    growthStage: string;
    soilType: string;
  }) => {
    const res = await api.post<{
      prediction: 'YES' | 'NO';
      priority: 'LOW' | 'MEDIUM' | 'HIGH';
      recommendedWaterAmount: string;
      confidence: number;
      reason: string;
      important_features: Array<{ feature: string; value: string }>;
      timestamp: string;
      disclaimer?: string;
    }>('/ml/predict/irrigation', data);
    return res.data;
  },
  predictCropSuitability: async (data: {
    nitrogen: number;
    phosphorus: number;
    potassium: number;
    temperature: number;
    humidity: number;
    ph: number;
    rainfall: number;
  }) => {
    const res = await api.post<{
      recommendedCrop: string;
      confidence: number;
      allRankings: Array<{ name: string; score: number }>;
      timestamp: string;
    }>('/ml/predict/crop-suitability', data);
    return res.data;
  },
  predictCropHealth: async (data: {
    soilMoisture: number;
    temperature: number;
    ph: number;
    nitrogen: number;
  }) => {
    const res = await api.post<{
      healthStatus: string;
      riskLevel: string;
      healthScore: number;
      confidence: number;
      timestamp: string;
    }>('/ml/predict/crop-health', data);
    return res.data;
  },
};

// Alert Services
export const alertService = {
  getAll: async (params?: { farmId?: string; status?: string; severity?: string }) => {
    const res = await api.get<Alert[]>('/alerts', { params });
    return res.data;
  },
  create: async (data: Partial<Alert>) => {
    const res = await api.post<Alert>('/alerts', data);
    return res.data;
  },
  resolve: async (id: string, resolvedBy?: string) => {
    const res = await api.put<Alert>(`/alerts/${id}/resolve`, { resolvedBy });
    return res.data;
  },
};

// Recommendation Services
export const recommendationService = {
  getAll: async (farmId?: string) => {
    const res = await api.get<Recommendation[]>('/recommendations', { params: { farmId } });
    return res.data;
  },
  create: async (data: Partial<Recommendation>) => {
    const res = await api.post<Recommendation>('/recommendations', data);
    return res.data;
  },
};

// Dataset Services
export const datasetService = {
  getAll: async () => {
    const res = await api.get<Dataset[]>('/datasets');
    return res.data;
  },
  getById: async (id: string) => {
    const res = await api.get<Dataset>(`/datasets/${id}`);
    return res.data;
  },
  upload: async (data: { name: string; csvData?: string; rows?: any[] }) => {
    const res = await api.post<Dataset>('/datasets/upload', data);
    return res.data;
  },
  clean: async (id: string) => {
    const res = await api.post<{ message: string; dataset: Dataset }>(`/datasets/${id}/clean`);
    return res.data;
  },
  getDownloadUrl: (id: string) => `/api/datasets/${id}/download`,
};

// Report Services
export const reportService = {
  getAll: async () => {
    const res = await api.get<any[]>('/reports');
    return res.data;
  },
  generate: async (data: { farmId: string; dateRange: string; crop: string; reportType: string }) => {
    const res = await api.post<any>('/reports/generate', data);
    return res.data;
  },
};

// Settings Services
export const settingsService = {
  get: async () => {
    const res = await api.get<ThresholdSettings>('/settings');
    return res.data;
  },
  update: async (data: Partial<ThresholdSettings>) => {
    const res = await api.put<ThresholdSettings>('/settings', data);
    return res.data;
  },
};

// User Management Services
export const userService = {
  getAll: async () => {
    const res = await api.get<User[]>('/users');
    return res.data;
  },
  create: async (data: Partial<User> & { password?: string }) => {
    const res = await api.post<User>('/users', data);
    return res.data;
  },
  update: async (id: string, data: Partial<User>) => {
    const res = await api.put<User>(`/users/${id}`, data);
    return res.data;
  },
  delete: async (id: string) => {
    const res = await api.delete(`/users/${id}`);
    return res.data;
  },
};

export default api;
