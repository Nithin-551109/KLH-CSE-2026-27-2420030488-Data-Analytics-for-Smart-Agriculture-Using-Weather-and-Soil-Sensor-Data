import React, { useState, useEffect } from 'react';
import {
  Sprout,
  Bell,
  RefreshCw,
  ChevronDown,
  LogOut,
  User as UserIcon,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  Layers,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { farmService, alertService } from '../../services/api';
import { Farm, Alert } from '../../types';
import { Badge } from '../common/Badge';

interface NavbarProps {
  onOpenAlerts?: () => void;
  onNavigate: (page: string) => void;
  currentPage: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onNavigate }) => {
  const {
    user,
    logout,
    quickDemoLogin,
    selectedFarmId,
    setSelectedFarmId,
    selectedRange,
    setSelectedRange,
    liveTick,
    triggerLivePulse,
  } = useAuth();

  const [farms, setFarms] = useState<Farm[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [showAlertMenu, setShowAlertMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [isPulsing, setIsPulsing] = useState(false);

  useEffect(() => {
    farmService.getAll().then(setFarms).catch(console.error);
  }, []);

  useEffect(() => {
    alertService.getAll({ status: 'ACTIVE' }).then(setAlerts).catch(console.error);
  }, [liveTick]);

  const handlePulse = () => {
    setIsPulsing(true);
    triggerLivePulse();
    setTimeout(() => setIsPulsing(false), 800);
  };

  const activeAlertsCount = alerts.filter((a) => a.status === 'ACTIVE').length;

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 lg:px-8 py-2.5 transition-all">
      <div className="flex items-center justify-between gap-4">
        {/* Farm & Range Selectors */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 bg-emerald-50/80 border border-emerald-200/70 rounded-lg px-2.5 py-1.5 text-xs text-emerald-900 font-medium">
            <Sprout className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline text-emerald-700/80 font-semibold">Active Farm:</span>
            <select
              value={selectedFarmId}
              onChange={(e) => setSelectedFarmId(e.target.value)}
              className="bg-transparent font-bold text-emerald-950 focus:outline-hidden cursor-pointer"
            >
              {farms.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.crop})
                </option>
              ))}
            </select>
          </div>

          {/* Time Range Filter */}
          <div className="hidden md:flex items-center gap-1.5 bg-slate-100 rounded-lg p-1 text-xs font-medium text-slate-600 border border-slate-200">
            <Calendar className="w-3.5 h-3.5 text-slate-400 ml-1.5" />
            {['Today', '7 Days', '30 Days', '3 Months'].map((range) => (
              <button
                key={range}
                onClick={() => setSelectedRange(range)}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  selectedRange === range
                    ? 'bg-white text-emerald-700 font-semibold shadow-2xs'
                    : 'hover:text-slate-900'
                }`}
              >
                {range}
              </button>
            ))}
          </div>

          {/* Real-time Telemetry Indicator */}
          <button
            onClick={handlePulse}
            title="Click to manually pulse real-time sensors"
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs text-slate-700 transition-colors shadow-2xs group"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-medium text-slate-600 hidden sm:inline">Telemetry:</span>
            <span className="font-semibold text-emerald-700">Online</span>
            <RefreshCw
              className={`w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-600 transition-transform ${
                isPulsing ? 'animate-spin text-emerald-600' : ''
              }`}
            />
          </button>
        </div>

        {/* Right Section: Alerts & User Profile */}
        <div className="flex items-center gap-3">
          {/* Alert Bell */}
          <div className="relative">
            <button
              onClick={() => setShowAlertMenu(!showAlertMenu)}
              className="relative p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            >
              <Bell className="w-5 h-5" />
              {activeAlertsCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                  {activeAlertsCount}
                </span>
              )}
            </button>

            {showAlertMenu && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-200 p-4 z-50 animate-in fade-in slide-in-from-top-2">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-800">Field Alerts</h4>
                    <Badge variant={activeAlertsCount > 0 ? 'red' : 'green'} size="sm">
                      {activeAlertsCount} active
                    </Badge>
                  </div>
                  <button
                    onClick={() => {
                      setShowAlertMenu(false);
                      onNavigate('alerts');
                    }}
                    className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold"
                  >
                    View All
                  </button>
                </div>

                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {alerts.length === 0 ? (
                    <p className="text-xs text-slate-400 py-3 text-center">No active anomalies detected.</p>
                  ) : (
                    alerts.slice(0, 4).map((a) => (
                      <div
                        key={a.id}
                        className={`p-2.5 rounded-lg border text-xs cursor-pointer hover:bg-slate-50 transition-colors ${
                          a.severity === 'CRITICAL'
                            ? 'bg-rose-50/50 border-rose-200 text-rose-900'
                            : 'bg-amber-50/50 border-amber-200 text-amber-900'
                        }`}
                        onClick={() => {
                          setShowAlertMenu(false);
                          onNavigate('alerts');
                        }}
                      >
                        <div className="flex items-center justify-between font-bold mb-1">
                          <span>{a.type}</span>
                          <span className="text-[10px] opacity-75">{new Date(a.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        <p className="line-clamp-2 text-slate-600">{a.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile & Demo Switcher */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2.5 pl-2 pr-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition-colors shadow-2xs"
            >
              <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                {user?.name?.charAt(0) || 'U'}
              </div>
              <div className="text-left hidden sm:block">
                <p className="text-xs font-bold text-slate-800 leading-tight">{user?.name || 'Guest User'}</p>
                <p className="text-[10px] font-semibold text-emerald-700 uppercase tracking-wider">
                  {user?.role || 'FARMER'}
                </p>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 p-3 z-50 animate-in fade-in">
                <div className="px-3 py-2 border-b border-slate-100 mb-2">
                  <p className="text-xs text-slate-400 font-medium">Signed in as</p>
                  <p className="text-xs font-bold text-slate-800 truncate">{user?.email}</p>
                  <div className="mt-1">
                    <Badge variant={user?.role === 'ADMIN' ? 'purple' : user?.role === 'RESEARCHER' ? 'blue' : 'green'} size="sm">
                      <ShieldCheck className="w-3 h-3" /> {user?.role}
                    </Badge>
                  </div>
                </div>

                {/* Quick Role Switcher for Evaluators */}
                <div className="px-3 py-1.5 mb-2 bg-slate-50 rounded-lg">
                  <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                    <Layers className="w-3 h-3" /> Switch Demo Role:
                  </p>
                  <div className="grid grid-cols-3 gap-1">
                    {(['ADMIN', 'FARMER', 'RESEARCHER'] as const).map((r) => (
                      <button
                        key={r}
                        onClick={() => {
                          quickDemoLogin(r);
                          setShowUserMenu(false);
                        }}
                        className={`text-[10px] font-bold py-1 px-1 rounded transition-colors ${
                          user?.role === r
                            ? 'bg-emerald-600 text-white'
                            : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {r === 'ADMIN' ? 'Admin' : r === 'FARMER' ? 'Farmer' : 'Research'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1">
                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      onNavigate('settings');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-1.5 text-xs font-medium text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
                  >
                    <UserIcon className="w-4 h-4 text-slate-400" /> Account Settings
                  </button>
                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      logout();
                      onNavigate('landing');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-1.5 text-xs font-medium text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                  >
                    <LogOut className="w-4 h-4 text-rose-500" /> Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
