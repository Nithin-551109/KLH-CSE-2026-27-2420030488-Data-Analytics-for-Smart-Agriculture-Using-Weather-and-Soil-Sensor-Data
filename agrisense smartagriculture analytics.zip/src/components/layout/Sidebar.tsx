import React from 'react';
import {
  LayoutDashboard,
  MapPin,
  CloudSun,
  Activity,
  Radio,
  Wheat,
  Droplets,
  AlertTriangle,
  BrainCircuit,
  LineChart,
  BellRing,
  FileText,
  Database,
  Users,
  Sliders,
  Home,
  ChevronRight,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentPage, onNavigate, isOpen, onClose }) => {
  const { user } = useAuth();

  const navItems = [
    {
      group: 'Core Telemetry',
      items: [
        { id: 'dashboard', label: 'Main Dashboard', icon: LayoutDashboard },
        { id: 'farms', label: 'Farm Management', icon: MapPin },
        { id: 'sensors', label: 'Sensor Monitoring', icon: Radio },
      ],
    },
    {
      group: 'Agronomic Analytics',
      items: [
        { id: 'weather', label: 'Weather Analytics', icon: CloudSun },
        { id: 'soil', label: 'Soil Analytics', icon: Activity },
        { id: 'crops', label: 'Crop Analytics', icon: Wheat },
      ],
    },
    {
      group: 'Decision Support & ML',
      items: [
        { id: 'irrigation', label: 'Irrigation Advisory', icon: Droplets, highlight: true },
        { id: 'correlative-analytics', label: 'Correlative Analytics', icon: LineChart },
        { id: 'disease-risk', label: 'Disease & Risks', icon: AlertTriangle },
        { id: 'ml-predictions', label: 'ML Predictions', icon: BrainCircuit },
        { id: 'research-analytics', label: 'Research Analytics', icon: LineChart },
      ],
    },
    {
      group: 'Data & Operations',
      items: [
        { id: 'alerts', label: 'Field Alerts', icon: BellRing },
        { id: 'reports', label: 'Audit Reports', icon: FileText },
        { id: 'datasets', label: 'Dataset Center', icon: Database },
        ...(user?.role === 'ADMIN'
          ? [{ id: 'users', label: 'User Management', icon: Users }]
          : []),
        { id: 'settings', label: 'System Settings', icon: Sliders },
      ],
    },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800 transition-transform duration-200 lg:static lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
          <div
            onClick={() => {
              onNavigate('landing');
              onClose();
            }}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-md shadow-emerald-950/40 group-hover:scale-105 transition-transform">
              <Wheat className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-extrabold text-white tracking-tight flex items-center gap-1">
                AgriSense <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">ML</span>
              </h1>
              <p className="text-[10px] text-slate-400 font-medium">Smart Agro-Analytics</p>
            </div>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
          {navItems.map((group) => (
            <div key={group.group}>
              <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-300/80 mb-2">
                {group.group}
              </p>
              <div className="space-y-1">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentPage === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onNavigate(item.id);
                        onClose();
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all group ${
                        isActive
                          ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-950/40'
                          : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon
                          className={`w-4 h-4 transition-colors ${
                            isActive
                              ? 'text-white'
                              : item.highlight
                              ? 'text-emerald-400'
                              : 'text-slate-400 group-hover:text-slate-200'
                          }`}
                        />
                        <span>{item.label}</span>
                      </div>
                      {item.highlight && !isActive && (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      )}
                      {isActive && <ChevronRight className="w-3.5 h-3.5 opacity-80" />}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Quick link to Landing / Research Project Overview */}
          <div className="pt-2 border-t border-slate-800/80">
            <button
              onClick={() => {
                onNavigate('landing');
                onClose();
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800/50 rounded-xl transition-colors"
            >
              <Home className="w-4 h-4" />
              <span>Project Overview / Portal</span>
            </button>
          </div>
        </div>

        {/* User Card in Sidebar Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/40">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-700/60 border border-emerald-500/30 flex items-center justify-center font-bold text-xs text-emerald-200">
              {user?.name?.charAt(0) || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-white truncate">{user?.name}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <p className="text-[10px] text-emerald-400 font-semibold truncate uppercase">{user?.role}</p>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
