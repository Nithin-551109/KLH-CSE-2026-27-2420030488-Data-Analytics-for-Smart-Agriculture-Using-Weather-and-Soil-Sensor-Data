import React from 'react';
import { Loader2 } from 'lucide-react';

export const LoadingSpinner: React.FC<{ message?: string; className?: string }> = ({
  message = 'Loading agricultural analytics...',
  className = 'h-64',
}) => {
  return (
    <div className={`flex flex-col items-center justify-center gap-3 w-full ${className}`}>
      <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
      <p className="text-sm font-medium text-slate-500">{message}</p>
    </div>
  );
};
