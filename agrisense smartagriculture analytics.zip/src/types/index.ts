export type UserRole = 'ADMIN' | 'FARMER' | 'RESEARCHER';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  farmId?: string;
  avatar?: string;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt?: string;
}

export interface Farm {
  id: string;
  name: string;
  ownerId: string;
  location: string;
  area: number;
  crop: string;
  soilType: 'Clay' | 'Loam' | 'Sandy Loam' | 'Black Soil' | 'Alluvial';
  sensorCount: number;
  status: 'ACTIVE' | 'INACTIVE';
  latitude: number;
  longitude: number;
  establishedDate: string;
}

export type SensorType =
  | 'Soil Moisture Sensor'
  | 'Temperature Sensor'
  | 'Humidity Sensor'
  | 'Soil pH Sensor'
  | 'Nitrogen Sensor'
  | 'Phosphorus Sensor'
  | 'Potassium Sensor'
  | 'Rainfall Sensor'
  | 'Light Intensity Sensor';

export interface Sensor {
  id: string;
  farmId: string;
  type: SensorType;
  currentValue: number;
  unit: string;
  status: 'ONLINE' | 'OFFLINE' | 'WARNING';
  lastUpdated: string;
  depthOrHeight?: string;
  batteryLevel: number;
  minNormal: number;
  maxNormal: number;
  statistics?: {
    min: number;
    max: number;
    avg: number;
    count: number;
  };
  recentReadings?: SensorReading[];
}

export interface SensorReading {
  id: string;
  sensorId: string;
  farmId: string;
  sensorType: string;
  value: number;
  unit: string;
  timestamp: string;
}

export interface ForecastDay {
  day: string;
  date: string;
  tempMin: number;
  tempMax: number;
  rainProb: number;
  condition: string;
  icon: string;
}

export interface WeatherData {
  farmId: string;
  temperature: number;
  humidity: number;
  rainfall: number;
  windSpeed: number;
  pressure: number;
  condition: string;
  forecast: ForecastDay[];
  lastUpdated: string;
}

export interface SoilData {
  farmId: string;
  farmName: string;
  soilType: string;
  moisture: number;
  temperature: number;
  ph: number;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  electricalConductivity: number;
  organicMatterPct: number;
  condition: 'DRY' | 'OPTIMAL' | 'WET' | 'CRITICAL';
  thresholds: {
    minMoisture: number;
    maxMoisture: number;
    minPh: number;
    maxPh: number;
  };
}

export type AlertSeverity = 'INFO' | 'WARNING' | 'CRITICAL';

export interface Alert {
  id: string;
  farmId: string;
  farmName: string;
  type: string;
  severity: AlertSeverity;
  message: string;
  timestamp: string;
  status: 'ACTIVE' | 'RESOLVED';
  resolvedAt?: string;
  resolvedBy?: string;
}

export interface Recommendation {
  id: string;
  farmId: string;
  farmName: string;
  type: 'IRRIGATION' | 'FERTILIZER' | 'PEST_CONTROL' | 'HARVEST';
  title: string;
  irrigationRequired: 'YES' | 'NO';
  priority: 'LOW' | 'MEDIUM' | 'HIGH';
  recommendedWaterAmount: string;
  recommendedAction: string;
  reason: string;
  confidenceScore: number;
  timestamp: string;
  factors: {
    soilMoisture: number;
    threshold: number;
    rainfallForecast: number;
    evapotranspiration: number;
    cropStage: string;
  };
}

export interface CropRecord {
  id: string;
  farmId: string;
  cropName: string;
  growthStage: 'Vegetative' | 'Tillering' | 'Flowering' | 'Grain Filling' | 'Maturity';
  plantingDate: string;
  expectedHarvestDate: string;
  waterRequirementDailyMm: number;
  optimalTempMin: number;
  optimalTempMax: number;
  optimalPhMin: number;
  optimalPhMax: number;
  healthStatus: 'Excellent' | 'Good' | 'Fair' | 'Under Stress' | 'Critical';
  healthScore: number;
}

export interface DashboardKPIs {
  totalFarms: number;
  activeSensors: number;
  totalSensors: number;
  avgSoilMoisture: number;
  avgTemperature: number;
  avgHumidity: number;
  rainfall: number;
  cropHealth: number;
  cropHealthStatus: string;
  waterRequirement: number;
  irrigationStatus: 'REQUIRED' | 'SUFFICIENT';
}

export interface DashboardAnalytics {
  kpis: DashboardKPIs;
  npk: Array<{ name: string; current: number; target: number; unit: string }>;
  trends: Array<{
    time: string;
    soilMoisture: number;
    temperature: number;
    humidity: number;
    rainfall: number;
    ph: number;
  }>;
  cropDistribution: Array<{ name: string; value: number; color: string }>;
  recentAlerts: Alert[];
  activeRecommendation: Recommendation;
}

export interface CorrelationData {
  datasetId?: string;
  datasetName?: string;
  variables: string[];
  matrix: Array<{
    feature: string;
    soilMoisture: number;
    temperature: number;
    humidity: number;
    rainfall: number;
    ph: number;
    cropHealth: number;
    nitrogen?: number;
    phosphorus?: number;
    potassium?: number;
  }>;
  keyFindings: string[];
  sampleRecords?: any[];
  pairDetails?: Array<{
    varA: string;
    varB: string;
    pearsonR: number;
    relationship: 'Strong Positive' | 'Moderate Positive' | 'Strong Negative' | 'Moderate Negative' | 'Weak/Neutral';
    agronomicImpact: string;
  }>;
}

export interface Dataset {
  id: string;
  name: string;
  uploadedBy: string;
  uploadedAt: string;
  recordCount: number;
  missingValues: number;
  duplicateCount: number;
  outlierCount: number;
  status: 'RAW' | 'CLEANED' | 'VALIDATED';
  dataPreview: any[];
}

export interface ThresholdSettings {
  minSoilMoisture: number;
  maxSoilMoisture: number;
  minPh: number;
  maxPh: number;
  tempWarning: number;
  humidityWarning: number;
  rainfallThreshold: number;
  minNitrogen: number;
  minPhosphorus: number;
  minPotassium: number;
  autoAlertsEnabled: boolean;
  refreshIntervalSeconds: number;
}
