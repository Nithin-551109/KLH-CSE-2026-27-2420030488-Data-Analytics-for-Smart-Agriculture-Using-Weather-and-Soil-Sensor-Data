import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { authService } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, role?: string) => Promise<void>;
  logout: () => void;
  quickDemoLogin: (role: UserRole) => Promise<void>;
  selectedFarmId: string;
  setSelectedFarmId: (farmId: string) => void;
  selectedRange: string;
  setSelectedRange: (range: string) => void;
  liveTick: number;
  triggerLivePulse: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('agrisense_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedFarmId, setSelectedFarmId] = useState<string>('farm-1');
  const [selectedRange, setSelectedRange] = useState<string>('7 Days');
  const [liveTick, setLiveTick] = useState<number>(0);

  // Auto-pulse sensor ticker every 10 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setLiveTick((prev) => prev + 1);
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  const triggerLivePulse = () => {
    setLiveTick((prev) => prev + 1);
  };

  useEffect(() => {
    const initAuth = async () => {
      const storedToken = localStorage.getItem('agrisense_token');
      if (storedToken) {
        try {
          const curUser = await authService.getCurrentUser();
          setUser(curUser);
          if (curUser.farmId) setSelectedFarmId(curUser.farmId);
        } catch (err) {
          console.warn('Session expired or invalid token', err);
          localStorage.removeItem('agrisense_token');
          setToken(null);
          // fallback to default demo user for frictionless review
          setUser({
            id: 'usr-1',
            name: 'Mohan',
            email: 'admin@agrisense.org',
            role: 'ADMIN',
            status: 'ACTIVE',
          });
        }
      } else {
        // Pre-authenticate with Admin role for instant preview experience
        setUser({
          id: 'usr-1',
          name: 'Mohan',
          email: 'admin@agrisense.org',
          role: 'ADMIN',
          status: 'ACTIVE',
        });
      }
      setIsLoading(false);
    };

    initAuth();
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const data = await authService.login({ email, password });
      localStorage.setItem('agrisense_token', data.token);
      setToken(data.token);
      setUser(data.user);
      if (data.user.farmId) {
        setSelectedFarmId(data.user.farmId);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string, role = 'FARMER') => {
    setIsLoading(true);
    try {
      const data = await authService.register({ name, email, password, role });
      localStorage.setItem('agrisense_token', data.token);
      setToken(data.token);
      setUser(data.user);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('agrisense_token');
    setToken(null);
    setUser(null);
  };

  const quickDemoLogin = async (role: UserRole) => {
    const creds: Record<UserRole, { email: string; pass: string }> = {
      ADMIN: { email: 'admin@agrisense.org', pass: 'admin123' },
      FARMER: { email: 'farmer@agrisense.org', pass: 'farmer123' },
      RESEARCHER: { email: 'researcher@agrisense.org', pass: 'research123' },
    };
    const c = creds[role];
    await login(c.email, c.pass);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        login,
        register,
        logout,
        quickDemoLogin,
        selectedFarmId,
        setSelectedFarmId,
        selectedRange,
        setSelectedRange,
        liveTick,
        triggerLivePulse,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
