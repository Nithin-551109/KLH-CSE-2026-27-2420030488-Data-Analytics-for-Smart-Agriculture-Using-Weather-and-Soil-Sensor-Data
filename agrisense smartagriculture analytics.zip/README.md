# DATA ANALYTICS FOR SMART AGRICULTURE USING WEATHER AND SOIL SENSOR DATA
**An End-to-End IoT & Machine Learning Precision Agriculture Platform**

[![Spring Boot 3](https://img.shields.io/badge/Spring%20Boot-3.2.3-green.svg)](https://spring.io/projects/spring-boot)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15-blue.svg)](https://www.postgresql.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110-teal.svg)](https://fastapi.tiangolo.com/)
[![React 19](https://img.shields.io/badge/React-19-cyan.svg)](https://react.dev/)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.4-orange.svg)](https://scikit-learn.org/)
[![License](https://img.shields.io/badge/License-Apache%202.0-lightgrey.svg)](LICENSE)

---

## 1. Project Description
**AgriSense** is an academic research and production-grade smart agriculture platform that integrates subterranean in-situ soil probes, automated microclimate weather telemetry, and machine learning models. By analyzing root-zone volumetric water content, soil chemistry ($N, P, K, pH$), and diurnal atmospheric trends, the platform provides automated, precision irrigation scheduling, crop health diagnostics, and threshold anomaly alerting to maximize water conservation and crop yield.

---

## 2. Core Features
- **Real-Time Sensor Telemetry:** Ingests live streams from 9 sensor categories (Soil Moisture, Temperature, Humidity, Soil pH, Nitrogen, Phosphorus, Potassium, Rainfall, Light Intensity).
- **Interactive Multi-Chart Dashboard:** Displays 8 real-time KPIs and 8 interactive Recharts visualizations (moisture decay curves, NPK balance, diurnal thermal cycles, weather vs. soil moisture coupling).
- **Subterranean Soil Analytics:** Configurable agronomic thresholds classify root-zone conditions into **DRY**, **OPTIMAL**, **WET**, and **CRITICAL** states.
- **Intelligent Irrigation Advisory:** Synthesizes root moisture deficits, evapotranspiration rates ($ET_0$), 48-hour precipitation outlooks, and crop growth stages to compute exact supplemental water depths ($mm$) and timing.
- **Predictive Machine Learning:**
  1. *Soil Moisture Regression:* Random Forest ($R^2 = 0.941$, $MAE = 1.42\%$)
  2. *Irrigation Classifier:* Gradient Boosted Decision Trees ($Accuracy = 96.3\%$, $F1 = 0.963$)
  3. *Crop Suitability Recommender:* $K$-Nearest Neighbors + Ensemble ($Accuracy = 94.8\%$)
  4. *Crop Health & Stress Classifier:* Multi-Class Random Forest ($Accuracy = 93.2\%$)
- **Research Analytics & Correlation Matrix:** Interactive Pearson correlation heatmap across all environmental parameters, descriptive statistics (mean, median, std dev, skewness), and scatter distribution plots.
- **Dataset Preprocessing Pipeline:** CSV tabular ingestion, missing value imputation, duplicate removal, 3-sigma outlier clipping, and download of cleaned benchmark datasets.
- **Role-Based Access Control (RBAC):** Dedicated views and privileges for `ADMIN`, `FARMER`, and `RESEARCHER`.
- **Automated Field Alerts & Audit Reports:** Real-time threshold breach notifications and comprehensive report generator with printable PDF views and CSV exports.

---

## 3. Architecture

```
                    SMART AGRICULTURE PLATFORM
                              │
          ┌───────────────────┴───────────────────┐
          │                                       │
    WEATHER DATA                              SOIL SENSORS
          │                                       │
          └───────────────────┬───────────────────┘
                              ↓
                     DATA COLLECTION
                              ↓
                     DATA PREPROCESSING
                              ↓
                    ┌─────────────────┐
                    │   PostgreSQL    │
                    └────────┬────────┘
                             ↓
                    DATA ANALYTICS
                             ↓
             ┌───────────────┼───────────────┐
             ↓               ↓               ↓
        Statistics      Correlation       ML Models
             │               │               │
             └───────────────┼───────────────┘
                             ↓
                   AGRICULTURAL INSIGHTS
                             ↓
        ┌────────────────────┼────────────────────┐
        ↓                    ↓                    ↓
  Irrigation            Crop Health           Alerts
  Recommendation        Prediction            & Risks
        │                    │                    │
        └────────────────────┼────────────────────┘
                             ↓
                     REACT DASHBOARD
```

---

## 4. Technology Stack

### Frontend:
- **Framework:** React 19 SPA, Vite 8, TypeScript
- **Styling:** Tailwind CSS 4, Plus Jakarta Sans, JetBrains Mono
- **Visualizations:** Recharts (Line, Area, Bar, Pie, Scatter charts)
- **Networking:** Axios with JWT request interceptors
- **Icons:** Lucide React

### Backend:
- **Language / Framework:** Java 17+, Spring Boot 3.2.x
- **Data Persistence:** Spring Data JPA, Hibernate, PostgreSQL
- **Security:** Spring Security, JWT (JSON Web Tokens), BCrypt password hashing
- **Build System:** Apache Maven

### Machine Learning & Data Analytics:
- **Framework:** Python 3.11, FastAPI, Uvicorn
- **Scientific Computing:** Pandas, NumPy, Scikit-Learn, Joblib
- **Evaluation Metrics:** MAE, MSE, RMSE, $R^2$, Accuracy, Precision, Recall, F1-Score

---

## 5. Project Structure

```
├── .env.example                     # Environment variable blueprints
├── docker-compose.yml               # Multi-container orchestration
├── Dockerfile.frontend              # React production Dockerfile
├── Dockerfile.backend               # Spring Boot multi-stage Dockerfile
├── Dockerfile.ml                    # Python ML microservice Dockerfile
├── server.ts                        # Full-stack Node/Express REST & simulation server
├── package.json                     # Frontend dependencies & scripts
│
├── src/                             # React Client Source
│   ├── components/
│   │   ├── common/                  # Reusable UI (StatCard, Badge, Modal, Spinner)
│   │   └── layout/                  # Navbar, Sidebar, telemetry tickers
│   ├── context/                     # AuthContext, role switchers, global farm filter
│   ├── pages/                       # 18 Modular agricultural dashboard pages
│   ├── services/                    # Modular Axios API services
│   └── types/                       # TypeScript interfaces
│
├── backend/                         # Spring Boot 3 Source
│   ├── pom.xml                      # Maven configuration
│   └── src/main/
│       ├── java/com/agrisense/      # Controllers, Entities, Repositories, Security
│       └── resources/               # application.properties
│
└── ml-service/                      # Python ML Service
    ├── requirements.txt             # ML dependencies
    ├── main.py                      # FastAPI inference endpoints
    └── models.py                    # Scikit-learn model definitions
```

---

## 6. Sample Credentials

For instant demonstration and evaluation:

| Role | Name | Email | Password | Permissions |
|---|---|---|---|---|
| **ADMIN** | Mohan | `admin@agrisense.org` | `admin123` | Full system access, farm provisioning, user & sensor management |
| **FARMER** | Suresh Reddy | `farmer@agrisense.org` | `farmer123` | Field telemetry, irrigation advisory, localized weather, alerts |
| **RESEARCHER** | Ananya Sharma | `researcher@agrisense.org` | `research123` | Dataset upload, preprocessing stats, ML model evaluation benchmarks |

*(You can also use the one-click role switcher in the user profile menu to test each perspective instantly.)*

---

## 7. REST API Documentation

### Authentication & Users
- `POST /api/auth/register` - Create account with role (`ADMIN`, `FARMER`, `RESEARCHER`)
- `POST /api/auth/login` - Authenticate and retrieve JWT token
- `GET /api/auth/me` - Validate session
- `GET /api/users` - List all system users (Admin only)
- `POST /api/users` - Create user

### Farms & Sensors
- `GET /api/farms` - Retrieve all farms
- `POST /api/farms` - Provision new farm with sensors
- `GET /api/sensors` - Query sensors by `farmId` or `type`
- `GET /api/sensors/:id` - Detailed historical sensor stats (min, max, avg)
- `POST /api/sensors/:id/readings` - Ingest real-time sensor reading pulse

### Agronomic Analytics
- `GET /api/analytics/dashboard` - Unified telemetry metrics and 8 trend datasets
- `GET /api/analytics/correlation` - Pearson correlation matrix and research findings
- `GET /api/analytics/statistics` - Descriptive statistics ($\mu, \text{median}, \sigma, \text{skewness}$)
- `GET /api/weather` - Current weather and 7-day microclimate forecast
- `GET /api/soil/:farmId` - Subterranean soil properties and threshold categorization

### Machine Learning Microservice
- `POST /api/ml/predict/soil-moisture` - Predict volumetric water content ($R^2 = 0.941$)
- `POST /api/ml/predict/irrigation` - Classify irrigation necessity and depth ($mm$)
- `POST /api/ml/predict/crop-suitability` - Recommend optimal crop based on soil chemistry
- `POST /api/ml/predict/crop-health` - Classify crop stress index and risk category

### Datasets & Reports
- `GET /api/datasets` - List research datasets
- `POST /api/datasets/upload` - Ingest CSV telemetry dataset
- `POST /api/datasets/:id/clean` - Execute preprocessing pipeline (impute & clip)
- `GET /api/datasets/:id/download` - Download sanitized CSV dataset
- `POST /api/reports/generate` - Generate agronomic compliance report

---

## 8. Setup & Execution

### Option A: Immediate Development Mode (Node.js & Vite)
The application includes a self-contained full-stack server running Express with Vite middleware:
```bash
# 1. Install dependencies
npm install

# 2. Run the full-stack platform
npm run dev
# Server listening on http://localhost:3000
```

### Option B: Docker Compose (Full-Stack 4-Tier Deployment)
To launch all services including PostgreSQL, Spring Boot, Python ML, and React:
```bash
docker-compose up --build
```
- **React Frontend:** `http://localhost:3000`
- **Spring Boot Backend:** `http://localhost:8080`
- **Python FastAPI ML Service:** `http://localhost:8000`
- **PostgreSQL Database:** `localhost:5432`

---

## 9. Demonstration Flow for Evaluators

1. **Portal Entry:** Open `http://localhost:3000` and review the architectural workflow and ML benchmarks on the **Landing Page**.
2. **Dashboard Overview:** Navigate to the **Main Dashboard** to view live telemetry from 36 active sensors across 4 monitored farms.
3. **Farm Selection:** Select *Green Valley Smart Farm (Telangana)* or *Sunrise Agri Estate (Punjab)* to dynamically observe differing microclimates.
4. **Soil Moisture & Thresholds:** Open **Soil Analytics** to examine the live classification (**DRY**, **OPTIMAL**, **WET**, **CRITICAL**) based on configurable backend thresholds.
5. **Irrigation Advisory:** Visit **Irrigation Recommendation** to see why the system prescribes 24–28 mm of drip irrigation, then use the **What-If Simulator** to test custom rain/temperature scenarios.
6. **Live Sensor Pulse:** Open **Sensor Monitoring** and click **Simulate Real-Time Pulse** or inject a manual reading to test threshold alerts.
7. **Machine Learning Workbench:** Open **ML Predictions** to run predictions across all 4 Scikit-Learn models and inspect empirical evaluation metrics ($MAE, RMSE, R^2, Accuracy, F1$).
8. **Research Correlation:** Open **Research Analytics** to explore the Pearson correlation heatmap and data cleaning pipeline statistics.
9. **Dataset Preprocessing:** In **Dataset Management**, view the 13-feature table, click **Execute Cleaning Pipeline** to impute missing values, and download the cleaned CSV.
10. **Report Export:** Generate a **Report** and click **Download / Print PDF** or **Export CSV**.
